---
name: xlsx
description: "Use this skill any time a spreadsheet file is the primary input or output. This means any task where the user wants to: open, read, edit, or fix an existing .xlsx, .xlsm, .csv, or .tsv file (e.g., adding columns, computing formulas, formatting, charting, cleaning messy data); create a new spreadsheet from scratch or from other data sources; or convert between tabular file formats. Trigger especially when the user references a spreadsheet file by name or path — even casually (like \"the xlsx in my downloads\") — and wants something done to it or produced from it. Also trigger for cleaning or restructuring messy tabular data files (malformed rows, misplaced headers, junk data) into proper spreadsheets. The deliverable must be a spreadsheet file. Do NOT trigger when the primary deliverable is a Word document, HTML report, standalone Python script, database pipeline, or Google Sheets API integration, even if tabular data is involved."
metadata:
  author: trae-skill
  version: "1.0.0"
  category: office-automation
  tags: [excel, xlsx, spreadsheet, pandas, openpyxl, data-analysis]
---

# XLSX Skill — Excel 文件处理专家

## 概述

本技能提供全面的 Excel (.xlsx) 文件处理能力，包括创建、读取、编辑、格式化、公式计算和数据验证。适用于数据分析、财务建模、报表生成等场景。

## 触发条件

当用户请求涉及以下内容时自动触发：
- 打开、读取、编辑或修复现有 .xlsx/.xlsm/.csv/.tsv 文件
- 从零创建新电子表格或从其他数据源生成
- 表格文件格式转换
- 用户提及电子表格文件名或路径

**不触发场景**：最终交付物为 Word 文档、HTML 报告、独立 Python 脚本、数据库管道或 Google Sheets API 集成时。

---

# 输出质量要求

## 所有 Excel 文件的通用要求

### 专业字体
- 所有交付物使用统一的专业字体（如 Arial、Times New Roman），除非用户另有指示

### 零公式错误
- 每个 Excel 模型必须交付时**零公式错误**（#REF!, #DIV/0!, #VALUE!, #N/A, #NAME?）

### 保留现有模板（更新模板时）
- 研究并**精确匹配**现有格式、样式和约定
- 不要对已有模式的文件强加标准化格式
- 现有模板约定**始终覆盖**这些指南

### 可视化表格设计（新建表格必须遵守，除非用户/模板另有说明）
- 在数据区域（非表头或合计行）应用**斑马纹**，使用低对比度交替填充（例如 `#FFFFFF` 和 `#F7F9FC`）
- 应用**细线浅色边框**构建结构（例如 `#D9DEE7`），优先使用外边框 + 行分隔线，而非粗重全网格边框
- 小计/合计行强调使用**层级提示**（加粗文本和/或顶部边框强调），而非每个单元格都用粗边框

### KPI 可视化层级（存在 KPI 类指标时必须遵守）
- 根据内容复杂度突出适当数量的关键指标，优先考虑汇总行、当期关键值和异常值
- 保持突出处理一致（优先加粗 + 浅色填充），避免过度使用饱和颜色
- 在整个工作簿中保持**颜色语义一致**（例如绿色=正面，红色=风险）
- 在关键指标旁添加简短标签（例如 "核心 KPI"、"异常"）

---

## 财务模型

### 颜色编码标准
除非用户或现有模板另有说明

#### 行业标准颜色约定
- **蓝色文本 (RGB: 0,0,255)**：硬编码输入，以及用户将在场景中更改的数字
- **黑色文本 (RGB: 0,0,0)**：所有公式和计算
- **绿色文本 (RGB: 0,128,0)**：从同一工作簿内其他工作表拉取的链接
- **红色文本 (RGB: 255,0,0)**：指向其他文件的外部链接
- **黄色背景 (RGB: 255,255,0)**：需要关注的关键假设或需要更新的单元格

### 数字格式标准

#### 必需格式规则
- **年份**：格式化为文本字符串（例如 "2024" 而非 "2,024"）
- **货币**：使用 $#,##0 格式；始终在表头中指定单位（"Revenue ($mm)"）
- **零值**：使用数字格式将所有零显示为 "-"，包括百分比（例如 "$#,##0;($#,##0);-"）
- **百分比**：默认 0.0% 格式（一位小数）
- **倍数**：估值倍数使用 0.0x 格式（EV/EBITDA, P/E）
- **负数**：使用括号 (123) 而非减号 -123

### 公式构建规则

#### 假设放置
- 将所有假设（增长率、利润率、倍数等）放在单独的假设单元格中
- 在公式中使用单元格引用而非硬编码值
- 示例：使用 `=B5*(1+$B$6)` 而非 `=B5*1.05`

#### 公式错误预防
- 验证所有单元格引用正确
- 检查范围中的偏移错误
- 确保所有预测期间的公式一致
- 用边界情况测试（零值、负数）
- 验证无意外循环引用

#### 硬编码值的文档要求
- 在单元格旁添加注释（如果在表格末尾）。格式："来源: [系统/文档], [日期], [具体引用], [URL（如适用）]"
- 示例：
  - "来源: Company 10-K, FY2024, 第45页, 营收注释, [SEC EDGAR URL]"
  - "来源: Bloomberg Terminal, 2025/8/15, AAPL US Equity"

---

# Excel 文件创建、编辑和分析

## 概述

用户可能要求创建、编辑或分析 .xlsx 文件的内容。针对不同任务，有不同的工具和工作流可用。

## 重要要求

**公式重算需要 LibreOffice**：可以假设已安装 LibreOffice，使用 `scripts/recalc.py` 脚本重算公式值。该脚本在首次运行时自动配置 LibreOffice，包括在 Unix 套接字受限的沙箱环境中（由 `scripts/office/soffice.py` 处理）。

## 数据读取与分析

### 使用 pandas 进行数据分析
对于数据分析、可视化和基本操作，使用 **pandas**，它提供强大的数据操作能力：

```python
import pandas as pd

# 读取 Excel
df = pd.read_excel('file.xlsx')  # 默认：第一个工作表
all_sheets = pd.read_excel('file.xlsx', sheet_name=None)  # 所有工作表为字典

# 分析
df.head()      # 预览数据
df.info()      # 列信息
df.describe()  # 统计信息

# 写入 Excel
df.to_excel('output.xlsx', index=False)
```

## Excel 文件工作流

## 关键原则：使用公式，而非硬编码值

**始终使用 Excel 公式而非在 Python 中计算并硬编码值。** 这确保电子表格保持动态和可更新。

### 错误示范 — 硬编码计算值
```python
# 错误：在 Python 中计算并硬编码结果
total = df['Sales'].sum()
sheet['B10'] = total  # 硬编码 5000

# 错误：在 Python 中计算增长率
growth = (df.iloc[-1]['Revenue'] - df.iloc[0]['Revenue']) / df.iloc[0]['Revenue']
sheet['C5'] = growth  # 硬编码 0.15

# 错误：Python 计算平均值
avg = sum(values) / len(values)
sheet['D20'] = avg  # 硬编码 42.5
```

### 正确做法 — 使用 Excel 公式
```python
# 正确：让 Excel 计算求和
sheet['B10'] = '=SUM(B2:B9)'

# 正确：增长率作为 Excel 公式
sheet['C5'] = '=(C4-C2)/C2'

# 正确：使用 Excel 函数计算平均值
sheet['D20'] = '=AVERAGE(D2:D19)'
```

这适用于所有计算 — 总计、百分比、比率、差值等。电子表格应能在源数据更改时重新计算。

## 必需：构建前规划

**在编写任何数据/公式/代码之前，必须完成以下规划步骤：**

### 步骤 1：问题审查
- 读取所有相关文件（源 Excel/CSV/TSV、模板工作簿和引用的文档）
- 将文件发现与用户查询结合，用具体术语重述任务意图

### 步骤 2：输出详细工作簿计划
呈现结构化计划，涵盖：

1. **工作表计划** — 工作表总数、每个工作表名称和用途
2. **Schema 计划（每个工作表）** — 行字段/列字段、每个字段的值来源/计算
3. **样式计划（每个工作表）** — 表头样式、斑马纹设计、KPI 可视化层级设计

**必需的规划输出格式：**
```markdown
## 问题审查
- 读取文件：...
- 任务理解：...

## 详细计划
### 工作表计划
1. 工作表: <名称> — 用途: <用途>

### Schema 计划
1. 工作表: <名称>
- 行字段：...
- 列字段：...
- 值来源/计算：...

### 样式计划
1. 工作表: <名称>
- 表头：...
- 斑马纹：...
- KPI 层级：...
```

如果输入不完整，仍需输出此计划并明确列出假设。

**仅在以下条件满足后才继续实施：**
- [ ] 问题审查完成
- [ ] 详细工作簿计划已输出

## 常用工作流

1. **首先输出计划（必需）**：使用上述必需格式输出问题审查 + 详细计划
2. **选择工具**：数据用 pandas，公式/格式用 openpyxl
3. **创建/加载**：创建新工作簿或加载现有文件
4. **修改**：添加/编辑数据、公式和格式
5. **保存**：写入文件
6. **重算公式（使用公式时必需）**：使用 scripts/recalc.py 脚本
   ```bash
   python scripts/recalc.py output.xlsx
   ```
7. **验证并修复错误**：
   - 脚本返回包含错误详情的 JSON
   - 如果 `status` 为 `errors_found`，检查 `error_summary` 获取具体错误类型和位置
   - 修复已识别的错误并重新计算

### 创建新 Excel 文件

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

wb = Workbook()
sheet = wb.active

sheet['A1'] = 'Hello'
sheet['B1'] = 'World'
sheet.append(['Row', 'of', 'data'])

sheet['B2'] = '=SUM(A1:A10)'

sheet['A1'].font = Font(bold=True, color='FF0000')
sheet['A1'].fill = PatternFill('solid', start_color='FFFF00')
sheet['A1'].alignment = Alignment(horizontal='center')

sheet.column_dimensions['A'].width = 20

wb.save('output.xlsx')
```

### 编辑现有 Excel 文件

```python
from openpyxl import load_workbook

wb = load_workbook('existing.xlsx')
sheet = wb.active  # 或 wb['SheetName'] 指定工作表

for sheet_name in wb.sheetnames:
    sheet = wb[sheet_name]

sheet['A1'] = 'New Value'
sheet.insert_rows(2)
sheet.delete_cols(3)

new_sheet = wb.create_sheet('NewSheet')
new_sheet['A1'] = 'Data'

wb.save('modified.xlsx')
```

## 公式重算

使用 openpyxl 创建或修改的 Excel 文件中，公式以字符串形式存在但未计算值。使用 `scripts/recalc.py` 脚本重算公式：

```bash
python scripts/recalc.py <excel_file> [timeout_seconds]
```

该脚本：
- 首次运行时自动设置 LibreOffice 宏
- 重算所有工作表中的所有公式
- 扫描所有单元格的 Excel 错误（#REF!, #DIV/0! 等）
- 返回包含详细错误位置和计数的 JSON
- 同时支持 Linux 和 macOS

## 公式验证清单

### 基本验证
- [ ] 测试 2-3 个样本引用：在构建完整模型前验证它们拉取正确值
- [ ] 列映射：确认 Excel 列匹配（例如第 64 列 = BL，而非 BK）
- [ ] 行偏移：记住 Excel 行从 1 开始索引（DataFrame 第 5 行 = Excel 第 6 行）

### 常见陷阱
- [ ] NaN 处理：使用 `pd.notna()` 检查空值
- [ ] 最右列：财年数据通常在第 50 列以上
- [ ] 多重匹配：搜索所有出现位置，而非仅第一个
- [ ] 除以零：在公式中使用 `/` 前检查分母
- [ ] 错误引用：验证所有单元格引用指向预期单元格
- [ ] 跨工作表引用：使用正确格式（Sheet1!A1）链接工作表

### 公式测试策略
- [ ] 从小处开始：在大范围应用前先在 2-3 个单元格上测试公式
- [ ] 验证依赖项：检查公式中引用的所有单元格是否存在
- [ ] 测试边界情况：包含零、负数和非常大的值

### 解读 scripts/recalc.py 输出
```json
{
  "status": "success",
  "total_errors": 0,
  "total_formulas": 42,
  "error_summary": {
    "#REF!": {
      "count": 2,
      "locations": ["Sheet1!B5", "Sheet1!C10"]
    }
  }
}
```

## 最佳实践

### 库选择
- **pandas**：最适合数据分析、批量操作和简单数据导出
- **openpyxl**：最适合复杂格式化、公式和 Excel 特有功能

### 使用 openpyxl
- 单元格索引从 1 开始（row=1, column=1 指单元格 A1）
- 使用 `data_only=True` 读取计算值：`load_workbook('file.xlsx', data_only=True)`
- **警告**：如果以 `data_only=True` 打开并保存，公式将被值替换且永久丢失
- 对于大文件：读取使用 `read_only=True`，写入使用 `write_only=True`
- 公式被保留但未计算 — 使用 scripts/recalc.py 更新值

### 使用 pandas
- 指定数据类型以避免推断问题：`pd.read_excel('file.xlsx', dtype={'id': str})`
- 对于大文件，读取特定列：`pd.read_excel('file.xlsx', usecols=['A', 'C', 'E'])`
- 正确处理日期：`pd.read_excel('file.xlsx', parse_dates=['date_column'])`

### 可复用样式辅助函数（openpyxl）

```python
from openpyxl.styles import PatternFill, Border, Side, Font

ZEBRA_FILL_1 = PatternFill(fill_type="solid", fgColor="FFFFFF")
ZEBRA_FILL_2 = PatternFill(fill_type="solid", fgColor="F7F9FC")
KPI_FILL = PatternFill(fill_type="solid", fgColor="EAF2FF")
THIN_BORDER = Border(
    left=Side(style="thin", color="D9DEE7"),
    right=Side(style="thin", color="D9DEE7"),
    top=Side(style="thin", color="D9DEE7"),
    bottom=Side(style="thin", color="D9DEE7"),
)
TOP_EMPHASIS_BORDER = Border(
    left=Side(style="thin", color="D9DEE7"),
    right=Side(style="thin", color="D9DEE7"),
    top=Side(style="medium", color="AAB4C5"),
    bottom=Side(style="thin", color="D9DEE7"),
)

def apply_zebra_style(ws, min_row, max_row, min_col, max_col):
    for r in range(min_row, max_row + 1):
        fill = ZEBRA_FILL_1 if (r - min_row) % 2 == 0 else ZEBRA_FILL_2
        for c in range(min_col, max_col + 1):
            ws.cell(r, c).fill = fill

def apply_light_borders(ws, min_row, max_row, min_col, max_col):
    for r in range(min_row, max_row + 1):
        for c in range(min_col, max_col + 1):
            ws.cell(r, c).border = THIN_BORDER

def highlight_kpis(ws, cells, label_col=None, label_text=None):
    for ref in cells:
        cell = ws[ref]
        cell.fill = KPI_FILL
        cell.font = Font(bold=True, color="1F2937")
    if label_col and label_text and cells:
        ws[f"{label_col}{ws[cells[0]].row}"] = label_text
```

## 代码风格指南

**重要**：生成 Excel 操作的 Python 代码时：
- 编写简洁的 Python 代码，避免不必要的注释
- 避免冗长的变量名和冗余操作
- 避免不必要的 print 语句

**对于 Excel 文件本身**：
- 为复杂公式或重要假设添加单元格注释
- 记录硬编码值的数据来源
- 为关键计算和模型部分添加说明

---

## 脚本工具说明

本技能附带以下脚本工具，位于 `scripts/` 目录下：

| 脚本 | 用途 |
|------|------|
| `recalc.py` | 使用 LibreOffice 重算 Excel 公式 |
| `office/unpack.py` | 解包 .xlsx/.docx/.pptx 为 XML 部件 |
| `office/pack.py` | 将 XML 部件打包回 OOXML 文件 |
| `office/soffice.py` | 使用 LibreOffice 进行格式转换 |
| `office/validate.py` | 基于 XSD schema 验证 OOXML 文件 |
| `office/validators/` | 各类型文件验证器（docx/pptx/redlining） |
| `office/helpers/` | XML 辅助工具（合并文本运行、简化修订标记） |
| `office/schemas/` | ISO/IEC 29500 XML Schema 定义文件 |
