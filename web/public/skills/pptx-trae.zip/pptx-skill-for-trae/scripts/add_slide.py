#!/usr/bin/env python3
"""Add or duplicate slides in unpacked PPTX.

Usage: python add_slide.py <unpacked_dir> <source_slide.xml>

Example:
    python add_slide.py unpacked/ slide2.xml      # Duplicate slide
    python add_slide.py unpacked/ slideLayout2.xml # From layout
"""

import sys
import shutil
import re
from pathlib import Path
from xml.etree import ElementTree as ET
import uuid


def get_next_slide_number(unpacked_dir: Path) -> int:
    """Get the next available slide number."""
    slides_dir = unpacked_dir / "ppt" / "slides"
    if not slides_dir.exists():
        return 1

    max_num = 0
    for slide_file in slides_dir.glob("slide*.xml"):
        match = re.match(r"slide(\d+)\.xml", slide_file.name)
        if match:
            max_num = max(max_num, int(match.group(1)))

    return max_num + 1


def get_next_rel_id(rels_path: Path) -> str:
    """Get the next available relationship ID."""
    if not rels_path.exists():
        return "rId1"

    tree = ET.parse(rels_path)
    root = tree.getroot()

    max_id = 0
    for rel in root.findall("{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):
        rid = rel.get("Id", "")
        match = re.match(r"rId(\d+)", rid)
        if match:
            max_id = max(max_id, int(match.group(1)))

    return f"rId{max_id + 1}"


def add_slide(unpacked_dir: str, source_file: str) -> None:
    """Add a new slide by duplicating an existing one."""
    unpacked_path = Path(unpacked_dir)
    source_path = unpacked_path / "ppt" / "slides" / source_file

    if not source_path.exists():
        # Try as layout
        source_path = unpacked_path / "ppt" / "slideLayouts" / source_file
        if not source_path.exists():
            print(f"Error: Source file not found: {source_file}", file=sys.stderr)
            sys.exit(1)

    slides_dir = unpacked_path / "ppt" / "slides"
    slides_rels_dir = slides_dir / "_rels"

    slides_dir.mkdir(parents=True, exist_ok=True)
    slides_rels_dir.mkdir(parents=True, exist_ok=True)

    # Get next slide number
    next_num = get_next_slide_number(unpacked_path)
    new_slide_name = f"slide{next_num}.xml"
    new_slide_path = slides_dir / new_slide_name

    # Copy slide file
    shutil.copy2(source_path, new_slide_path)

    # Handle slide relationships
    source_rels = source_path.parent / "_rels" / f"{source_path.name}.rels"
    new_rels_path = slides_rels_dir / f"{new_slide_name}.rels"

    if source_rels.exists():
        shutil.copy2(source_rels, new_rels_path)

    # Update presentation.xml.rels
    pres_rels_path = unpacked_path / "ppt" / "_rels" / "presentation.xml.rels"
    if pres_rels_path.exists():
        tree = ET.parse(pres_rels_path)
        root = tree.getroot()

        ns = {"rel": "http://schemas.openxmlformats.org/package/2006/relationships"}

        new_rid = get_next_rel_id(pres_rels_path)

        rel = ET.SubElement(root, "{http://schemas.openxmlformats.org/package/2006/relationships}Relationship")
        rel.set("Id", new_rid)
        rel.set("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide")
        rel.set("Target", f"slides/{new_slide_name}")

        tree.write(pres_rels_path, encoding="UTF-8", xml_declaration=True)

    # Output the sldId element to add to presentation.xml
    print(f"Created: {new_slide_name}")
    print(f"Add this to presentation.xml <p:sldIdLst>:")
    print(f'  <p:sldId id="{256 + next_num}" r:id="{new_rid}"/>')


def main():
    if len(sys.argv) != 3:
        print("Usage: python add_slide.py <unpacked_dir> <source_slide.xml>", file=sys.stderr)
        sys.exit(1)

    add_slide(sys.argv[1], sys.argv[2])


if __name__ == "__main__":
    main()
