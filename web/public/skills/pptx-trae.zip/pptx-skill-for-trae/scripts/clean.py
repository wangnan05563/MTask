#!/usr/bin/env python3
"""Clean orphaned files from unpacked PPTX directory.

Usage: python clean.py <unpacked_dir>

Removes:
- Slides not referenced in presentation.xml
- Unreferenced media files
- Orphaned relationship files
"""

import sys
import re
import shutil
from pathlib import Path
from xml.etree import ElementTree as ET


def fix_shadow_overflow(unpacked_dir: Path) -> int:
    """Fix shadow parameter overflow values in slide XML files."""
    fix_count = 0
    slides_dir = unpacked_dir / "ppt" / "slides"
    if not slides_dir.exists():
        return fix_count

    for slide_file in slides_dir.glob("*.xml"):
        content = slide_file.read_text(encoding="utf-8")
        original = content

        # Fix shadow overflow values (blurRad, dist, dir, alpha)
        # These should be within valid EMU ranges
        content = re.sub(r'blurRad="(\d{10,})"', r'blurRad="2147483647"', content)
        content = re.sub(r'dist="(\d{10,})"', r'dist="2147483647"', content)
        content = re.sub(r'dir="(\d{10,})"', r'dir="21600000"', content)
        content = re.sub(r'alpha="(\d{3,})"', r'alpha="100000"', content)

        if content != original:
            slide_file.write_text(content, encoding="utf-8")
            fix_count += 1

    return fix_count


def fix_double_bullets(unpacked_dir: Path) -> int:
    """Fix double bullet characters in slide XML files."""
    fix_count = 0
    slides_dir = unpacked_dir / "ppt" / "slides"
    if not slides_dir.exists():
        return fix_count

    bullet_pattern = re.compile(r'([\u2022\u2023\u25E6\u2043\u2219\u00B7\u25CF\u25CB])\s*\1')

    for slide_file in slides_dir.glob("*.xml"):
        content = slide_file.read_text(encoding="utf-8")
        original = content

        # Remove duplicate bullet characters
        content = bullet_pattern.sub(r'\1', content)

        if content != original:
            slide_file.write_text(content, encoding="utf-8")
            fix_count += 1

    return fix_count


def clean(unpacked_dir: str) -> None:
    """Clean orphaned files from unpacked PPTX directory."""
    unpacked_path = Path(unpacked_dir)

    if not unpacked_path.exists():
        print(f"Error: {unpacked_dir} not found", file=sys.stderr)
        sys.exit(1)

    presentation_xml = unpacked_path / "ppt" / "presentation.xml"
    if not presentation_xml.exists():
        print(f"Error: presentation.xml not found in {unpacked_dir}", file=sys.stderr)
        sys.exit(1)

    # Parse presentation.xml to find referenced slides
    try:
        tree = ET.parse(presentation_xml)
        root = tree.getroot()

        # Find all slide IDs in sldIdLst
        ns = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
              "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}

        sld_id_lst = root.find(".//p:sldIdLst", ns)
        if sld_id_lst is None:
            print("Warning: sldIdLst not found in presentation.xml")
            return

        referenced_ids = set()
        for sld_id in sld_id_lst.findall("p:sldId", ns):
            rid = sld_id.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            if rid:
                referenced_ids.add(rid)

        # Check presentation.xml.rels for slide references
        pres_rels = unpacked_path / "ppt" / "_rels" / "presentation.xml.rels"
        if pres_rels.exists():
            rels_tree = ET.parse(pres_rels)
            rels_root = rels_tree.getroot()

            ns_rels = {"rel": "http://schemas.openxmlformats.org/package/2006/relationships"}
            slide_rels = {}

            for rel in rels_root.findall("rel:Relationship", ns_rels):
                rid = rel.get("Id")
                target = rel.get("Target")
                rel_type = rel.get("Type", "")

                if "slide" in rel_type.lower() and rid in referenced_ids:
                    slide_rels[rid] = target

            # Remove unreferenced slides
            slides_dir = unpacked_path / "ppt" / "slides"
            slides_rels_dir = unpacked_path / "ppt" / "slides" / "_rels"

            if slides_dir.exists():
                for slide_file in slides_dir.glob("slide*.xml"):
                    slide_name = f"slides/{slide_file.name}"

                    # Check if this slide is referenced
                    is_referenced = any(target == slide_name or target == f"./{slide_file.name}"
                                      for target in slide_rels.values())

                    if not is_referenced:
                        print(f"Removing orphaned slide: {slide_file.name}")
                        slide_file.unlink()

                        # Also remove slide rels file if exists
                        rels_file = slides_rels_dir / f"{slide_file.name}.rels"
                        if rels_file.exists():
                            rels_file.unlink()

        print("Clean completed")

    except Exception as e:
        print(f"Error during clean: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python clean.py <unpacked_dir>", file=sys.stderr)
        sys.exit(1)

    clean(sys.argv[1])
