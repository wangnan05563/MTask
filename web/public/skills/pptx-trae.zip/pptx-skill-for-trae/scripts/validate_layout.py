#!/usr/bin/env python3
"""
PPTX Layout Validator - Detect layout issues in PowerPoint presentations.

This validator checks for critical layout issues:
1. Elements exceeding slide boundaries
2. Elements overlapping with each other
3. Blank slides
4. Table content overflow

Usage:
    python validate_layout.py <pptx_file> [--verbose] [--slides 3,5,8]
"""

import argparse
import io
import math
import re
import sys
import zipfile
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, List, Tuple, Dict, Set

import defusedxml.minidom
from PIL import Image


# Namespaces for OOXML
NAMESPACES = {
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}

# EMU (English Metric Unit) conversions
EMU_PER_INCH = 914400
EMU_PER_POINT = 12700
EMU_PER_CM = 360000


@dataclass
class BoundingBox:
    """Represents a bounding box in EMU units."""
    x: int
    y: int
    w: int
    h: int

    @property
    def right(self) -> int:
        return self.x + self.w

    @property
    def bottom(self) -> int:
        return self.y + self.h

    def overlaps(self, other: "BoundingBox") -> bool:
        """Check if this box overlaps with another box."""
        return (self.x < other.right and
                self.right > other.x and
                self.y < other.bottom and
                self.bottom > other.y)

    def contains(self, other: "BoundingBox") -> bool:
        return (self.x <= other.x and self.y <= other.y
                and self.right >= other.right and self.bottom >= other.bottom)

    def to_cm(self) -> Tuple[float, float, float, float]:
        """Convert to centimeters for display."""
        return (
            self.x / EMU_PER_CM,
            self.y / EMU_PER_CM,
            self.w / EMU_PER_CM,
            self.h / EMU_PER_CM
        )


@dataclass
class SlideElement:
    """Represents an element on a slide."""
    element_type: str
    name: str
    bbox: BoundingBox
    xml_path: str
    line_number: int
    is_connector: bool = False
    has_text: bool = False
    is_decorative: bool = False


@dataclass
class SlideInfo:
    """Information about a single slide."""
    slide_number: int
    xml_path: str
    width: int
    height: int
    elements: List[SlideElement]


@dataclass
class LayoutIssue:
    """Represents a layout issue found on a slide."""
    issue_type: str
    slide_number: int
    description: str
    elements: List[SlideElement]
    priority: str = "P0"


class PPTXLayoutValidator:
    """Validator for PPTX layout issues."""

    def __init__(self, pptx_path: Optional[str] = None, verbose: bool = False, slide_filter: Optional[Set[int]] = None):
        self.pptx_path = Path(pptx_path) if pptx_path else None
        self.verbose = verbose
        self.slide_filter = slide_filter
        self.slides: List[SlideInfo] = []
        self.issues: List[LayoutIssue] = []

    def validate(self) -> bool:
        """Run all validation checks."""
        if not self.pptx_path.exists():
            print(f"Error: File not found: {self.pptx_path}", file=sys.stderr)
            return False

        if self.pptx_path.suffix.lower() != ".pptx":
            print(f"Error: Not a PPTX file: {self.pptx_path}", file=sys.stderr)
            return False

        self._extract_slide_info()

        if self.verbose:
            print(f"Found {len(self.slides)} slides")

        for slide in self.slides:
            if self.slide_filter and slide.slide_number not in self.slide_filter:
                continue
            self._check_blank_slide(slide)
            self._check_slide_boundaries(slide)
            self._check_element_overlaps(slide)

        return len(self.issues) == 0

    def _extract_slide_info(self) -> None:
        """Extract slide information from the PPTX file."""
        with zipfile.ZipFile(self.pptx_path, "r") as zf:
            # Get presentation.xml to find slide order and dimensions
            try:
                pres_content = zf.read("ppt/presentation.xml")
                pres_dom = defusedxml.minidom.parseString(pres_content)

                # Get slide dimensions
                sld_sz = pres_dom.getElementsByTagName("p:sldSz")
                if sld_sz:
                    cx = int(sld_sz[0].getAttribute("cx"))
                    cy = int(sld_sz[0].getAttribute("cy"))
                else:
                    cx, cy = 9144000, 5143500  # Default 16:9

                # Get slide IDs in order
                sld_id_lst = pres_dom.getElementsByTagName("p:sldIdLst")
                if sld_id_lst:
                    slide_ids = []
                    for sld_id in sld_id_lst[0].getElementsByTagName("p:sldId"):
                        rid = sld_id.getAttribute("r:id")
                        slide_ids.append(rid)

                    # Get slide paths from relationships
                    try:
                        rels_content = zf.read("ppt/_rels/presentation.xml.rels")
                        rels_dom = defusedxml.minidom.parseString(rels_content)

                        slide_num = 1
                        for rid in slide_ids:
                            rel = self._find_relationship(rels_dom, rid)
                            if rel:
                                target = rel.getAttribute("Target")
                                slide_path = f"ppt/{target}"

                                try:
                                    slide_content = zf.read(slide_path)
                                    elements = self._parse_slide_elements(slide_content, slide_path)

                                    self.slides.append(SlideInfo(
                                        slide_number=slide_num,
                                        xml_path=slide_path,
                                        width=cx,
                                        height=cy,
                                        elements=elements
                                    ))
                                except KeyError:
                                    if self.verbose:
                                        print(f"Warning: Slide file not found: {slide_path}")

                                slide_num += 1
                    except KeyError:
                        pass

            except Exception as e:
                print(f"Error parsing presentation: {e}", file=sys.stderr)

    def _find_relationship(self, rels_dom, rid: str):
        """Find a relationship by ID."""
        for rel in rels_dom.getElementsByTagName("Relationship"):
            if rel.getAttribute("Id") == rid:
                return rel
        return None

    def _parse_slide_elements(self, slide_content: bytes, xml_path: str) -> List[SlideElement]:
        """Parse slide XML to extract elements with their bounding boxes."""
        elements = []

        try:
            slide_dom = defusedxml.minidom.parseString(slide_content)

            # Find all shapes
            for sp in slide_dom.getElementsByTagName("p:sp"):
                element = self._parse_shape(sp, xml_path)
                if element:
                    elements.append(element)

            # Find all pictures
            for pic in slide_dom.getElementsByTagName("p:pic"):
                element = self._parse_picture(pic, xml_path)
                if element:
                    elements.append(element)

            # Find all graphic frames (charts, tables)
            for graphic_frame in slide_dom.getElementsByTagName("p:graphicFrame"):
                element = self._parse_graphic_frame(graphic_frame, xml_path)
                if element:
                    elements.append(element)

        except Exception as e:
            if self.verbose:
                print(f"Error parsing slide {xml_path}: {e}")

        return elements

    def _parse_shape(self, sp, xml_path: str) -> Optional[SlideElement]:
        """Parse a shape element."""
        try:
            # Get shape name
            nv_sp_pr = sp.getElementsByTagName("p:nvSpPr")
            name = "Shape"
            if nv_sp_pr:
                cnv_pr = nv_sp_pr[0].getElementsByTagName("p:cNvPr")
                if cnv_pr:
                    name = cnv_pr[0].getAttribute("name") or "Shape"

            # Get transform
            sp_pr = sp.getElementsByTagName("p:spPr")
            if not sp_pr:
                return None

            xfrm = sp_pr[0].getElementsByTagName("a:xfrm")
            if not xfrm:
                return None

            bbox = self._parse_transform(xfrm[0])
            if not bbox:
                return None

            # Check if has text
            has_text = len(sp.getElementsByTagName("a:t")) > 0

            return SlideElement(
                element_type="shape",
                name=name,
                bbox=bbox,
                xml_path=xml_path,
                line_number=0,
                has_text=has_text
            )

        except Exception:
            return None

    def _parse_picture(self, pic, xml_path: str) -> Optional[SlideElement]:
        """Parse a picture element."""
        try:
            # Get picture name
            nv_pic_pr = pic.getElementsByTagName("p:nvPicPr")
            name = "Image"
            if nv_pic_pr:
                cnv_pr = nv_pic_pr[0].getElementsByTagName("p:cNvPr")
                if cnv_pr:
                    name = cnv_pr[0].getAttribute("name") or "Image"

            # Get transform
            sp_pr = pic.getElementsByTagName("p:spPr")
            if not sp_pr:
                return None

            xfrm = sp_pr[0].getElementsByTagName("a:xfrm")
            if not xfrm:
                return None

            bbox = self._parse_transform(xfrm[0])
            if not bbox:
                return None

            return SlideElement(
                element_type="image",
                name=name,
                bbox=bbox,
                xml_path=xml_path,
                line_number=0
            )

        except Exception:
            return None

    def _parse_graphic_frame(self, graphic_frame, xml_path: str) -> Optional[SlideElement]:
        """Parse a graphic frame (chart/table)."""
        try:
            # Get frame name
            nv_graphic_frame_pr = graphic_frame.getElementsByTagName("p:nvGraphicFramePr")
            name = "Graphic"
            if nv_graphic_frame_pr:
                cnv_pr = nv_graphic_frame_pr[0].getElementsByTagName("p:cNvPr")
                if cnv_pr:
                    name = cnv_pr[0].getAttribute("name") or "Graphic"

            # Get transform
            xfrm = graphic_frame.getElementsByTagName("a:xfrm")
            if not xfrm:
                return None

            bbox = self._parse_transform(xfrm[0])
            if not bbox:
                return None

            # Determine type
            element_type = "graphic"
            if graphic_frame.getElementsByTagName("a:chart"):
                element_type = "chart"
            elif graphic_frame.getElementsByTagName("a:tbl"):
                element_type = "table"

            return SlideElement(
                element_type=element_type,
                name=name,
                bbox=bbox,
                xml_path=xml_path,
                line_number=0
            )

        except Exception:
            return None

    def _parse_transform(self, xfrm) -> Optional[BoundingBox]:
        """Parse transform element to get bounding box."""
        try:
            off = xfrm.getElementsByTagName("a:off")
            ext = xfrm.getElementsByTagName("a:ext")

            if not off or not ext:
                return None

            x = int(off[0].getAttribute("x"))
            y = int(off[0].getAttribute("y"))
            w = int(ext[0].getAttribute("cx"))
            h = int(ext[0].getAttribute("cy"))

            return BoundingBox(x, y, w, h)

        except Exception:
            return None

    def _check_blank_slide(self, slide: SlideInfo) -> None:
        """Check if a slide has no visible content."""
        # Filter out decorative elements
        content_elements = [e for e in slide.elements if not e.is_decorative]

        if len(content_elements) == 0:
            self.issues.append(LayoutIssue(
                issue_type="blank_slide",
                slide_number=slide.slide_number,
                description=f"Slide {slide.slide_number} has no visible content elements",
                elements=[],
                priority="P0"
            ))

    def _check_slide_boundaries(self, slide: SlideInfo) -> None:
        """Check if elements exceed slide boundaries."""
        for element in slide.elements:
            if element.is_decorative:
                continue

            issues = []

            if element.bbox.x < 0:
                issues.append(f"left edge ({element.bbox.x / EMU_PER_CM:.1f}cm)")
            if element.bbox.y < 0:
                issues.append(f"top edge ({element.bbox.y / EMU_PER_CM:.1f}cm)")
            if element.bbox.right > slide.width:
                issues.append(f"right edge ({element.bbox.right / EMU_PER_CM:.1f}cm > {slide.width / EMU_PER_CM:.1f}cm)")
            if element.bbox.bottom > slide.height:
                issues.append(f"bottom edge ({element.bbox.bottom / EMU_PER_CM:.1f}cm > {slide.height / EMU_PER_CM:.1f}cm)")

            if issues:
                self.issues.append(LayoutIssue(
                    issue_type="boundary",
                    slide_number=slide.slide_number,
                    description=f"Slide {slide.slide_number}: '{element.name}' exceeds {', '.join(issues)}",
                    elements=[element],
                    priority="P0"
                ))

    def _check_element_overlaps(self, slide: SlideInfo) -> None:
        """Check for overlapping elements on a slide."""
        # Skip connector lines and decorative elements
        check_elements = [e for e in slide.elements
                         if not e.is_connector and not e.is_decorative]

        for i, elem1 in enumerate(check_elements):
            for elem2 in check_elements[i + 1:]:
                if elem1.bbox.overlaps(elem2.bbox):
                    self.issues.append(LayoutIssue(
                        issue_type="overlap",
                        slide_number=slide.slide_number,
                        description=f"Slide {slide.slide_number}: '{elem1.name}' overlaps with '{elem2.name}'",
                        elements=[elem1, elem2],
                        priority="P1"
                    ))

    def print_report(self) -> None:
        """Print validation report."""
        print("=" * 60)
        print("PPTX Layout Validation Report")
        print("=" * 60)
        print(f"File: {self.pptx_path}")
        print(f"Slides checked: {len([s for s in self.slides if not self.slide_filter or s.slide_number in self.slide_filter])}")
        print(f"Total issues: {len(self.issues)}")
        print()

        if not self.issues:
            print("✓ No layout issues found!")
            return

        # Group issues by type
        boundary_issues = [i for i in self.issues if i.issue_type == "boundary"]
        overlap_issues = [i for i in self.issues if i.issue_type == "overlap"]
        blank_issues = [i for i in self.issues if i.issue_type == "blank_slide"]

        if blank_issues:
            print("⚠ BLANK SLIDES (Critical):")
            for issue in blank_issues:
                print(f"  - {issue.description}")
            print()

        if boundary_issues:
            print("⚠ BOUNDARY VIOLATIONS (Critical):")
            for issue in boundary_issues:
                print(f"  - {issue.description}")
            print()

        if overlap_issues:
            print("⚠ ELEMENT OVERLAPS (Warning):")
            for issue in overlap_issues:
                print(f"  - {issue.description}")
            print()

        print("=" * 60)


def main():
    parser = argparse.ArgumentParser(description="Validate PPTX layout")
    parser.add_argument("pptx_file", help="Path to PPTX file")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    parser.add_argument("--slides", help="Comma-separated list of slide numbers to validate")

    args = parser.parse_args()

    slide_filter = None
    if args.slides:
        slide_filter = set(int(s.strip()) for s in args.slides.split(","))

    validator = PPTXLayoutValidator(
        pptx_path=args.pptx_file,
        verbose=args.verbose,
        slide_filter=slide_filter
    )

    is_valid = validator.validate()
    validator.print_report()

    sys.exit(0 if is_valid else 1)


if __name__ == "__main__":
    main()
