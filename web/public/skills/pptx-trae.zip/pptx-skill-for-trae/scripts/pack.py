#!/usr/bin/env python3
"""Pack unpacked PPTX directory into a PPTX file.

Usage: python pack.py <unpacked_dir> <output.pptx> [--original original.pptx]

Example:
    python pack.py unpacked/ output.pptx --original template.pptx
"""

import sys
import zipfile
import argparse
from pathlib import Path
from xml.etree import ElementTree as ET


def pack(unpacked_dir: str, output_file: str, original_file: str = None) -> None:
    """Pack unpacked PPTX directory into a PPTX file."""
    unpacked_path = Path(unpacked_dir)
    output_path = Path(output_file)

    if not unpacked_path.exists():
        print(f"Error: {unpacked_dir} not found", file=sys.stderr)
        sys.exit(1)

    # Validate XML files before packing
    xml_files = list(unpacked_path.rglob("*.xml"))
    for xml_file in xml_files:
        try:
            ET.parse(xml_file)
        except ET.ParseError as e:
            print(f"Warning: XML parse error in {xml_file}: {e}", file=sys.stderr)

    # Create output PPTX
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in sorted(unpacked_path.rglob("*")):
            if file_path.is_file():
                arcname = file_path.relative_to(unpacked_path)
                zf.write(file_path, arcname)

    print(f"Packed {unpacked_dir} to {output_file}")


def main():
    parser = argparse.ArgumentParser(description="Pack unpacked PPTX directory")
    parser.add_argument("unpacked_dir", help="Path to unpacked directory")
    parser.add_argument("output_file", help="Path to output PPTX file")
    parser.add_argument("--original", help="Path to original PPTX file (for reference)")

    args = parser.parse_args()
    pack(args.unpacked_dir, args.output_file, args.original)


if __name__ == "__main__":
    main()
