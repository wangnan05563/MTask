# PPTX Skill for Trae IDE

专业级 PPT 创建技能，专为 Trae IDE 设计。基于 SOLO 的 pptx skill 最佳实践，提供完整的演示文稿制作指南和工具集。

## 功能特性

- **从零创建**: 使用 pptxgenjs 创建专业级 PPT
- **模板编辑**: 基于现有模板修改和定制
- **布局验证**: 自动检测边界溢出、元素重叠、空白幻灯片等问题
- **设计系统**: 提供配色方案、字体搭配、布局建议
- **CJK 支持**: 完整支持中文、日文、韩文字体

## 快速开始

### 安装依赖

```bash
# Python 依赖
pip install defusedxml pillow markitdown[pptx]

# Node.js 依赖
npm install -g pptxgenjs
```

### 创建新演示文稿

1. 阅读 [SKILL.md](SKILL.md) 了解完整工作流程
2. 参考 [pptxgenjs.md](pptxgenjs.md) 编写生成脚本
3. 运行验证确保质量

### 编辑现有模板

1. 阅读 [editing.md](editing.md) 了解模板编辑流程
2. 使用 `unpack.py` 解压 PPTX
3. 修改 XML 内容
4. 使用 `pack.py` 重新打包

## 项目结构

```
pptx-skill-for-trae/
├── SKILL.md              # 主技能文档
├── editing.md            # 模板编辑指南
├── pptxgenjs.md          # pptxgenjs 开发指南
├── README.md             # 本文件
├── package.json          # 项目配置
└── scripts/              # 工具脚本
    ├── unpack.py         # 解压 PPTX
    ├── pack.py           # 打包 PPTX
    ├── clean.py          # 清理孤儿文件
    ├── fix_pptx.py       # 修复生成问题
    ├── validate_layout.py # 布局验证
    └── add_slide.py      # 添加幻灯片
```

## 核心工作流程

### 1. 从零创建

```bash
# 1. 编写生成脚本 (generate.js)
node generate.js

# 2. 修复已知问题
python3 scripts/fix_pptx.py output.pptx

# 3. 验证布局
python3 scripts/validate_layout.py output.pptx

# 4. 内容验证
python3 -m markitdown output.pptx
```

### 2. 模板编辑

```bash
# 1. 解压
python3 scripts/unpack.py template.pptx unpacked/

# 2. 编辑 XML 文件

# 3. 清理和打包
python3 scripts/clean.py unpacked/
python3 scripts/pack.py unpacked/ output.pptx --original template.pptx

# 4. 验证
python3 scripts/validate_layout.py output.pptx --slides 3,5,8
```

## 设计原则

- **标题使用衬线字体** (Georgia, Cambria 等)
- **正文使用无衬线字体** (Calibri, Arial 等)
- **每页必须有视觉元素** (图表、图片、图标)
- **遵循 0.5" 边距规范**
- **使用一致的配色方案**

## 验证规则

`validate_layout.py` 会检查：

- ✅ 空白幻灯片检测
- ✅ 元素边界溢出
- ✅ 元素重叠检测
- ✅ 表格内容溢出

## 许可证

MIT
