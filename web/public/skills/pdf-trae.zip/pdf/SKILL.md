---
name: pdf
description: "Comprehensive PDF manipulation toolkit for extracting text and tables, creating new PDFs, merging/splitting documents, and handling forms. When you need to fill in a PDF form or programmatically process, generate, or analyze PDF documents at scale."
metadata:
  author: trae-skill
  version: "1.0.0"
  category: document-processing
  tags: [pdf, extract, create, merge, split, form, OCR, text, table]
---

# PDF 处理指南

## 概述

本指南涵盖使用 Python 库和命令行工具进行 PDF 处理的基本操作。高级功能、JavaScript 库及详细示例请参阅附录中的「高级参考」。如需填写 PDF 表单，请参阅附录中的「表单处理指南」并按照其说明操作。

## 快速入门

```python
from pypdf import PdfReader, PdfWriter

# 读取 PDF
reader = PdfReader("document.pdf")
print(f"页数: {len(reader.pages)}")

# 提取文本
text = ""
for page in reader.pages:
    text += page.extract_text()
```

## 长 PDF 处理工作流

当 PDF 文件较长时，不要依赖单次全文输出。应先逐页提取文件，然后使用关键词或正则表达式进行搜索。
`extract_pages.py` 在提取过程中会移除 `(cid:123)` 格式的垃圾标记，以减少上下文浪费。
当检测到长合并标记时，它还会通过回退到词级别提取来修复英文文本中缺失的空格。

### 多查询搜索工作流

如果你有多个查询需要搜索，**绝不要多次单独调用 `search_extracted.sh`**。正确的做法是：
1. 将所有查询写入一个文本文件（每行一个查询）
2. 使用 `--query-file` 一次性搜索所有查询
3. 脚本会自动跨所有查询去重页面

```bash
# 创建 queries.txt，每行一个查询
echo "find methodology" > queries.txt
echo "find results" >> queries.txt
echo "find conclusion" >> queries.txt

# 一次性搜索所有查询并自动去重
bash scripts/search_extracted.sh extracted --query-file queries.txt
```

### 强制检索规则

对于面向任务的处理（例如准备 PPT 材料），必须始终使用基于查询的检索方式从提取文件中获取信息。

- **必须**：提取到 `pages/page_XXXX.txt`
- **必须**：根据用户意图和关键约束构建任务级长查询
- **必须**：运行 `search_extracted.sh` 并使用匹配文件作为证据
- **必须**：对于命中的页面，使用完整匹配页面作为上下文
- **必须**：当命中位于前 5 行内时，包含前一页
- **必须**：当命中位于后 5 行内时，包含下一页
- **必须**：对已包含的上下文页面进行去重
- **禁止**：默认读取固定页面范围（如前 20 页）
- **禁止**：将大范围页面拼接成一个长上下文

```bash
# 1) 逐页提取文本文件
python3 scripts/extract_pages.py input.pdf extracted

# 输出:
# extracted/pages/page_0001.txt
# extracted/pages/page_0002.txt
# ...

# 2) 任务级长查询搜索（短语提取 + 召回/重排序）
bash scripts/search_extracted.sh extracted "find methodology and experimental setup for ReAct with action-observation loop and reasoning traces"

# 3) 正则表达式搜索
bash scripts/search_extracted.sh extracted "ReAct|reasoning|agent" --regex

# 4) 多查询搜索，跨查询页面去重
# queries.txt 每行包含一个查询
bash scripts/search_extracted.sh extracted --query-file queries.txt
```

### 端到端示例

```bash
# 目标：从长 PDF 中查找"方法 + 指标"的证据

python3 scripts/extract_pages.py report.pdf extracted

# 查找与方法论相关的证据
bash scripts/search_extracted.sh extracted "find method section describing interleaved reasoning and acting with concrete procedure details"

# 从页面文本中查找数字证据
bash scripts/search_extracted.sh extracted "[0-9]{4}|[0-9]+%" --regex
```

对于页面文件，每次命中返回整个页面作为上下文。如果命中位于页面边界附近（前 5 行或后 5 行），相邻页面也会被包含一次。
对于长查询，搜索脚本会自动提取短语和关键词，计算 IDF 加权的召回/重排序，并在上下文扩展前保留前 3 个匹配页面。
当使用 `--query-file` 时，匹配页面在最终输出前会跨所有查询进行去重。
使用匹配文件路径（例如 `pages/page_0031.txt`）作为下游任务的直接证据输入。

### 回退策略

如果 `search_extracted.sh` 返回"No matches found"，应回退到直接读取所有提取的页面文件。按顺序遍历 `pages/page_XXXX.txt`，读取每个页面的内容作为上下文。

### 反模式（请勿使用）

```python
# 错误做法：固定范围读取会导致无关上下文并遗漏关键证据
with pdfplumber.open("document.pdf") as pdf:
    full_text = ""
    for page in pdf.pages[:20]:
        full_text += page.extract_text() or ""
```

始终优先使用"提取到文件 + grep 检索"而非固定范围全文读取。

## Python 库

### pypdf - 基本操作

#### 合并 PDF
```python
from pypdf import PdfWriter, PdfReader

writer = PdfWriter()
for pdf_file in ["doc1.pdf", "doc2.pdf", "doc3.pdf"]:
    reader = PdfReader(pdf_file)
    for page in reader.pages:
        writer.add_page(page)

with open("merged.pdf", "wb") as output:
    writer.write(output)
```

#### 拆分 PDF
```python
reader = PdfReader("input.pdf")
for i, page in enumerate(reader.pages):
    writer = PdfWriter()
    writer.add_page(page)
    with open(f"page_{i+1}.pdf", "wb") as output:
        writer.write(output)
```

#### 提取元数据
```python
reader = PdfReader("document.pdf")
meta = reader.metadata
print(f"标题: {meta.title}")
print(f"作者: {meta.author}")
print(f"主题: {meta.subject}")
print(f"创建者: {meta.creator}")
```

#### 旋转页面
```python
reader = PdfReader("input.pdf")
writer = PdfWriter()

page = reader.pages[0]
page.rotate(90)  # 顺时针旋转 90 度
writer.add_page(page)

with open("rotated.pdf", "wb") as output:
    writer.write(output)
```

### pdfplumber - 文本和表格提取

#### 带布局的文本提取
```python
import pdfplumber

with pdfplumber.open("document.pdf") as pdf:
    for page in pdf.pages:
        text = page.extract_text()
        print(text)
```

#### 提取表格
```python
with pdfplumber.open("document.pdf") as pdf:
    for i, page in enumerate(pdf.pages):
        tables = page.extract_tables()
        for j, table in enumerate(tables):
            print(f"第 {i+1} 页的表格 {j+1}:")
            for row in table:
                print(row)
```

#### 高级表格提取
```python
import pandas as pd

with pdfplumber.open("document.pdf") as pdf:
    all_tables = []
    for page in pdf.pages:
        tables = page.extract_tables()
        for table in tables:
            if table:  # 检查表格是否非空
                df = pd.DataFrame(table[1:], columns=table[0])
                all_tables.append(df)

# 合并所有表格
if all_tables:
    combined_df = pd.concat(all_tables, ignore_index=True)
    combined_df.to_excel("extracted_tables.xlsx", index=False)
```

### reportlab - 创建 PDF

#### CJK 字体支持（中文/日文/韩文）

创建包含非 ASCII 文本（如中文、日文、韩文）的 PDF 时，**必须**先注册支持 CJK 的字体：

```python
import os
import platform
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

def register_cjk_font():
    """根据操作系统注册支持 CJK 的字体"""
    system = platform.system()

    if system == "Darwin":  # macOS
        font_paths = [
            "/System/Library/Fonts/PingFang.ttc",
            "/Library/Fonts/Arial Unicode.ttf",
            "/System/Library/Fonts/STHeiti Medium.ttc",
        ]
    elif system == "Windows":
        font_paths = [
            "C:/Windows/Fonts/msyh.ttc",  # 微软雅黑
            "C:/Windows/Fonts/simsun.ttc",  # 宋体
        ]
    else:  # Linux
        font_paths = [
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        ]

    for font_path in font_paths:
        if os.path.exists(font_path):
            pdfmetrics.registerFont(TTFont("CJKFont", font_path, subfontIndex=0))
            return "CJKFont"
    return None

# 创建 PDF 前先注册 CJK 字体
cjk_font = register_cjk_font()
```

#### 专业样式（必须使用）

始终使用以下精心设计的样式来生成专业外观的 PDF：

```python
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor

PRIMARY_COLOR = HexColor('#1a365d')
ACCENT_COLOR = HexColor('#2b6cb0')

def get_professional_styles(cjk_font='CJKFont'):
    """返回用于 PDF 生成的专业样式字典"""
    return {
        'title': ParagraphStyle(
            'Title', fontName=cjk_font, fontSize=28, leading=34,
            textColor=PRIMARY_COLOR, spaceAfter=20, alignment=1, wordWrap='CJK'
        ),
        'subtitle': ParagraphStyle(
            'Subtitle', fontName=cjk_font, fontSize=14, leading=18,
            textColor=HexColor('#4a5568'), spaceAfter=30, alignment=1, wordWrap='CJK'
        ),
        'h1': ParagraphStyle(
            'H1', fontName=cjk_font, fontSize=20, leading=26,
            textColor=PRIMARY_COLOR, spaceBefore=24, spaceAfter=12, wordWrap='CJK'
        ),
        'h2': ParagraphStyle(
            'H2', fontName=cjk_font, fontSize=16, leading=22,
            textColor=ACCENT_COLOR, spaceBefore=18, spaceAfter=8, wordWrap='CJK'
        ),
        'body': ParagraphStyle(
            'Body', fontName=cjk_font, fontSize=11, leading=18,
            textColor=HexColor('#2d3748'), spaceBefore=0, spaceAfter=10,
            firstLineIndent=0, wordWrap='CJK'
        ),
        'caption': ParagraphStyle(
            'Caption', fontName=cjk_font, fontSize=9, leading=12,
            textColor=HexColor('#718096'), alignment=1, spaceBefore=6, spaceAfter=12, wordWrap='CJK'
        ),
    }

# 使用方法
styles = get_professional_styles('CJKFont')
story.append(Paragraph("标题 Title", styles['title']))
story.append(Paragraph("第一章 Chapter 1", styles['h1']))
story.append(Paragraph("正文内容...", styles['body']))
```

#### 专业表格样式

```python
from reportlab.lib.colors import HexColor
from reportlab.platypus import Table, LongTable
from reportlab.lib import colors

def create_styled_table(data, col_widths=None, is_large=False):
    """创建专业样式的表格"""
    TableClass = LongTable if is_large else Table
    table = TableClass(data, colWidths=col_widths, repeatRows=1 if is_large else 0)

    table.setStyle([
        ('BACKGROUND', (0, 0), (-1, 0), HexColor('#2b6cb0')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, -1), 'CJKFont'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('TOPPADDING', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
        ('TOPPADDING', (0, 1), (-1, -1), 8),
        ('BACKGROUND', (0, 1), (-1, -1), HexColor('#f7fafc')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor('#f7fafc'), colors.white]),
        ('GRID', (0, 0), (-1, -1), 0.5, HexColor('#e2e8f0')),
    ])
    return table
```

#### 行内文本格式化

在 Paragraph 中使用类 HTML 标签实现富文本：

```python
from reportlab.platypus import Paragraph

text = """
<b>粗体 Bold</b>, <i>斜体 Italic</i>, <u>下划线 Underline</u>
<font color="#2b6cb0">蓝色文字 Blue text</font>
<font size="14">大字号 Larger</font>, <font size="9">小字号 Smaller</font>
化学式: H<sub>2</sub>O, 数学: E=mc<sup>2</sup>
<br/>换行 Line break
"""
story.append(Paragraph(text, styles['body']))
```

| 标签 | 效果 |
|-----|--------|
| `<b>` | **粗体** |
| `<i>` | *斜体* |
| `<u>` | 下划线 |
| `<font color="...">` | 颜色 |
| `<font size="...">` | 字号 |
| `<sub>` | 下标 |
| `<sup>` | 上标 |
| `<br/>` | 换行 |

#### 文本对齐

```python
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.lib.styles import ParagraphStyle

left_style = ParagraphStyle('Left', alignment=TA_LEFT)
center_style = ParagraphStyle('Center', alignment=TA_CENTER)
right_style = ParagraphStyle('Right', alignment=TA_RIGHT)
justify_style = ParagraphStyle('Justify', alignment=TA_JUSTIFY)
```

#### 彩色分隔线

在标题和副标题下方添加装饰性分隔线，增强视觉层次：

```python
from reportlab.platypus import Flowable
from reportlab.lib.colors import HexColor
from reportlab.lib.units import inch

class ColoredDivider(Flowable):
    """彩色水平分隔线"""
    def __init__(self, width, height=2, color=HexColor('#2b6cb0'), space_before=6, space_after=12):
        Flowable.__init__(self)
        self.width = width
        self.height = height
        self.color = color
        self.spaceAfter = space_after
        self.spaceBefore = space_before

    def draw(self):
        self.canv.setFillColor(self.color)
        self.canv.rect(0, 0, self.width, self.height, fill=1, stroke=0)

# 预定义分隔线
CONTENT_WIDTH = 6.5 * inch

def title_divider():
    """文档标题下方的宽装饰线"""
    return ColoredDivider(CONTENT_WIDTH, height=3, color=HexColor('#2b6cb0'), space_after=20)

def h1_divider():
    """H1 标题下方的中等宽度分隔线"""
    return ColoredDivider(CONTENT_WIDTH * 0.3, height=2, color=HexColor('#2b6cb0'), space_after=12)

def subtle_divider():
    """章节间的细灰色分隔线"""
    return ColoredDivider(CONTENT_WIDTH, height=1, color=HexColor('#e2e8f0'), space_after=10)

# 在 story 中使用
story.append(Paragraph("报告标题 Report Title", styles['title']))
story.append(title_divider())  # 标题下方的装饰线

story.append(Paragraph("第一章 Chapter 1", styles['h1']))
story.append(h1_divider())  # H1 下方的短装饰线

story.append(Paragraph("正文内容...", styles['body']))
story.append(subtle_divider())  # 细微的章节分隔线
```

#### 文档设置与正确边距

```python
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate

doc = SimpleDocTemplate(
    "report.pdf",
    pagesize=letter,
    leftMargin=0.75*inch,
    rightMargin=0.75*inch,
    topMargin=0.75*inch,
    bottomMargin=0.75*inch,
)
```

#### 分页最佳实践（重要）

**核心原则**：让内容自然流动。尽量减少 `PageBreak` 和 `KeepTogether` 的使用。

| 内容类型 | 添加方式 | KeepTogether? | PageBreak? |
|---------|-----------|---------------|------------|
| 封面页 | `story.append()` + 之后加 `PageBreak()` | 否 | **仅在封面之后** |
| **标题** | 直接 `story.append()` | **否** | **否** |
| **段落** | 直接 `story.append()` | **否** | **否** |
| 图片 + 说明 | `KeepTogether([Image, Paragraph])` | 是 | 否 |
| 小表格 | `KeepTogether([Table])` | 是 | 否 |
| 大表格 | `LongTable(..., repeatRows=1)` | 否 | 否 |

**常见错误 #1 - 过多的 PageBreak：**
```python
# 错误：不要在章节/节之前添加 PageBreak！
story.append(PageBreak())  # 会创建浪费的空白！
story.append(Paragraph("Chapter 2", heading_style))

# 正确：直接添加标题，内容自然流动
story.append(Paragraph("Chapter 2", heading_style))
```
**规则：仅在封面页之后使用一次 PageBreak。其他任何地方都不要使用 PageBreak！**

**常见错误 #2 - 对标题/段落使用 KeepTogether：**
```python
# 错误：会产生半页空白！
story.append(KeepTogether([
    Paragraph("Chapter 2", heading_style),
    Paragraph("长内容...", body_style),
]))

# 正确：直接添加，让内容自然流动和分页
story.append(Paragraph("Chapter 2", heading_style))
story.append(Paragraph("长内容...", body_style))
```

**完整示例：**
```python
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, KeepTogether

# 1. 先注册 CJK 字体（使用上面的 register_cjk_font()）
register_cjk_font()

# 2. 设置正确边距的文档
doc = SimpleDocTemplate("report.pdf", pagesize=letter,
    leftMargin=0.75*inch, rightMargin=0.75*inch,
    topMargin=0.75*inch, bottomMargin=0.75*inch)

# 3. 使用专业样式（使用上面的 get_professional_styles()）
styles = get_professional_styles('CJKFont')

story = []

# 封面 - 仅在这里使用 PageBreak
story.append(Spacer(1, 2*inch))
story.append(Paragraph("报告标题 Report Title", styles['title']))
story.append(Paragraph("副标题 Subtitle", styles['subtitle']))
story.append(PageBreak())

# 标题和段落 - 直接添加（不使用 KeepTogether，不使用 PageBreak）
story.append(Paragraph("第一章 Introduction", styles['h1']))
story.append(Paragraph("正文内容自然流动，可跨页分割...", styles['body']))
story.append(Paragraph("1.1 背景 Background", styles['h2']))
story.append(Paragraph("更多内容...", styles['body']))

# 图片 - 使用 KeepTogether
story.append(KeepTogether([
    Image("fig.png", width=400, height=300),
    Paragraph("图 1: 说明文字", styles['caption'])
]))

# 表格 - 使用上面的 create_styled_table()
story.append(KeepTogether([create_styled_table(small_data)]))

doc.build(story)
```

### matplotlib - 支持 CJK 的图表

使用 matplotlib 创建包含中文文本的图表/图形时，**必须**配置字体：

```python
import os
import platform
import matplotlib.pyplot as plt
import matplotlib

def setup_matplotlib_cjk():
    """配置 matplotlib 以支持 CJK 字符"""
    system = platform.system()

    if system == "Darwin":  # macOS
        font_names = ['Arial Unicode MS', 'PingFang SC', 'Heiti SC', 'STHeiti']
    elif system == "Windows":
        font_names = ['Microsoft YaHei', 'SimHei', 'SimSun']
    else:  # Linux
        font_names = ['Noto Sans CJK SC', 'WenQuanYi Zen Hei', 'Droid Sans Fallback']

    # 查找可用字体
    available_fonts = [f.name for f in matplotlib.font_manager.fontManager.ttflist]
    for font_name in font_names:
        if font_name in available_fonts:
            plt.rcParams['font.sans-serif'] = [font_name] + plt.rcParams['font.sans-serif']
            plt.rcParams['axes.unicode_minus'] = False  # 修复负号显示
            return font_name
    return None

# 创建图表前先设置 CJK 字体
cjk_font = setup_matplotlib_cjk()

# 创建带中文标签的柱状图
categories = ['第一季度', '第二季度', '第三季度', '第四季度']
values = [120, 135, 142, 158]

plt.figure(figsize=(10, 6))
plt.bar(categories, values, color='steelblue')
plt.title('季度销售数据 Quarterly Sales', fontsize=16)
plt.xlabel('季度 Quarter', fontsize=12)
plt.ylabel('销售额 Sales', fontsize=12)
plt.tight_layout()
plt.savefig('chart.png', dpi=150)
plt.close()
```

#### 将 matplotlib 图表嵌入 PDF
```python
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Image, Paragraph, Spacer
from reportlab.lib.styles import ParagraphStyle

# 先创建并保存图表（见上文）
# 然后将其嵌入 PDF

doc = SimpleDocTemplate("report_with_chart.pdf", pagesize=letter)
story = []

# 添加标题
cjk_style = ParagraphStyle('CJKStyle', fontName='CJKFont', fontSize=14, wordWrap='CJK')
story.append(Paragraph("销售报告 Sales Report", cjk_style))
story.append(Spacer(1, 20))

# 添加图表图片
chart_img = Image('chart.png', width=400, height=240)
story.append(chart_img)
story.append(Spacer(1, 20))

# 添加描述
story.append(Paragraph("图表显示了四个季度的销售数据变化趋势。", cjk_style))

doc.build(story)
```

## 命令行工具

### pdftotext (poppler-utils)
```bash
# 提取文本
pdftotext input.pdf output.txt

# 保留布局提取文本
pdftotext -layout input.pdf output.txt

# 提取特定页面
pdftotext -f 1 -l 5 input.pdf output.txt  # 第 1-5 页
```

### qpdf
```bash
# 合并 PDF
qpdf --empty --pages file1.pdf file2.pdf -- merged.pdf

# 拆分页面
qpdf input.pdf --pages . 1-5 -- pages1-5.pdf
qpdf input.pdf --pages . 6-10 -- pages6-10.pdf

# 旋转页面
qpdf input.pdf output.pdf --rotate=+90:1  # 将第 1 页旋转 90 度

# 移除密码
qpdf --password=mypassword --decrypt encrypted.pdf decrypted.pdf
```

### pdftk（如可用）
```bash
# 合并
pdftk file1.pdf file2.pdf cat output merged.pdf

# 拆分
pdftk input.pdf burst

# 旋转
pdftk input.pdf rotate 1east output rotated.pdf
```

## 常见任务

### 从扫描版 PDF 中提取文本
```python
# 需要: pip install pytesseract pdf2image
import pytesseract
from pdf2image import convert_from_path

# 将 PDF 转换为图片
images = convert_from_path('scanned.pdf')

# 对每页进行 OCR
text = ""
for i, image in enumerate(images):
    text += f"第 {i+1} 页:\n"
    text += pytesseract.image_to_string(image)
    text += "\n\n"

print(text)
```

### 添加水印
```python
from pypdf import PdfReader, PdfWriter

# 创建水印（或加载已有水印）
watermark = PdfReader("watermark.pdf").pages[0]

# 应用到所有页面
reader = PdfReader("document.pdf")
writer = PdfWriter()

for page in reader.pages:
    page.merge_page(watermark)
    writer.add_page(page)

with open("watermarked.pdf", "wb") as output:
    writer.write(output)
```

### 提取图片
```bash
# 使用 pdfimages (poppler-utils)
pdfimages -j input.pdf output_prefix

# 这将提取所有图片为 output_prefix-000.jpg, output_prefix-001.jpg 等
```

### 密码保护
```python
from pypdf import PdfReader, PdfWriter

reader = PdfReader("input.pdf")
writer = PdfWriter()

for page in reader.pages:
    writer.add_page(page)

# 添加密码
writer.encrypt("userpassword", "ownerpassword")

with open("encrypted.pdf", "wb") as output:
    writer.write(output)
```

## 快速参考

| 任务 | 最佳工具 | 命令/代码 |
|------|-----------|--------------|
| 合并 PDF | pypdf | `writer.add_page(page)` |
| 拆分 PDF | pypdf | 每页一个文件 |
| 提取文本 | pdfplumber | `page.extract_text()` |
| 提取表格 | pdfplumber | `page.extract_tables()` |
| 提取长 PDF 页面 | `scripts/extract_pages.py` | `python3 scripts/extract_pages.py input.pdf extracted` |
| 搜索提取的文件 | `scripts/search_extracted.sh` | `bash scripts/search_extracted.sh extracted "long query" [--regex]` |
| 创建 PDF | reportlab | Canvas 或 Platypus |
| 命令行合并 | qpdf | `qpdf --empty --pages ...` |
| OCR 扫描版 PDF | pytesseract | 先转换为图片 |
| 填写 PDF 表单 | pdf-lib 或 pypdf（见表单处理指南） | 见表单处理指南 |

## 脚本工具说明

| 脚本名称 | 用途 | 使用方法 |
|---------|------|---------|
| `check_bounding_boxes.py` | 检查边界框是否有重叠或尺寸过小 | `python scripts/check_bounding_boxes.py fields.json` |
| `check_fillable_fields.py` | 检查 PDF 是否包含可填写表单字段 | `python scripts/check_fillable_fields.py <file.pdf>` |
| `convert_pdf_to_images.py` | 将 PDF 转换为 PNG 图片 | `python scripts/convert_pdf_to_images.py <file.pdf> <output_dir>` |
| `create_validation_image.py` | 创建验证图片 | `python scripts/create_validation_image.py` |
| `extract_form_field_info.py` | 提取可填写表单字段信息为 JSON | `python scripts/extract_form_field_info.py <input.pdf> <field_info.json>` |
| `extract_form_structure.py` | 提取表单结构（标签、线条、复选框） | `python scripts/extract_form_structure.py <input.pdf> <form_structure.json>` |
| `extract_pages.py` | 逐页提取 PDF 文本 | `python scripts/extract_pages.py <input.pdf> <output_dir>` |
| `fill_fillable_fields.py` | 填写可填写表单字段 | `python scripts/fill_fillable_fields.py <input.pdf> <field_values.json> <output.pdf>` |
| `fill_pdf_form_with_annotations.py` | 使用文本注释填写 PDF 表单 | `python scripts/fill_pdf_form_with_annotations.py <input.pdf> <fields.json> <output.pdf>` |
| `search_extracted.py` | 搜索提取的页面文本（Python 接口） | `python scripts/search_extracted.py` |
| `search_extracted.sh` | 搜索提取的页面文本（Shell 接口） | `bash scripts/search_extracted.sh <extracted_dir> "query" [--regex] [--query-file queries.txt]` |

---

---

# 附录 A：表单处理指南

**关键：你必须按顺序完成以下步骤。不要跳过直接编写代码。**

如果需要填写 PDF 表单，首先检查 PDF 是否有可填写的表单字段。从本文件所在目录运行以下脚本：
`python scripts/check_fillable_fields <file.pdf>`，根据结果跳转到"可填写字段"或"不可填写字段"部分并按照说明操作。

## 可填写字段

如果 PDF 包含可填写表单字段：
- 从本文件所在目录运行此脚本：`python scripts/extract_form_field_info.py <input.pdf> <field_info.json>`。它将创建一个 JSON 文件，包含以下格式的字段列表：
```
[
  {
    "field_id": (字段的唯一 ID),
    "page": (页码，从 1 开始),
    "rect": ([left, bottom, right, top] PDF 坐标中的边界框，y=0 为页面底部),
    "type": ("text"、"checkbox"、"radio_group" 或 "choice"),
  },
  // 复选框具有 "checked_value" 和 "unchecked_value" 属性：
  {
    "field_id": (字段的唯一 ID),
    "page": (页码，从 1 开始),
    "type": "checkbox",
    "checked_value": (将字段设置为此值以勾选复选框),
    "unchecked_value": (将字段设置为此值以取消勾选复选框),
  },
  // 单选按钮组具有 "radio_options" 列表，包含可选选项。
  {
    "field_id": (字段的唯一 ID),
    "page": (页码，从 1 开始),
    "type": "radio_group",
    "radio_options": [
      {
        "value": (将字段设置为此值以选择此单选按钮选项),
        "rect": (此选项单选按钮的边界框)
      },
      // 其他单选按钮选项
    ]
  },
  // 多选字段具有 "choice_options" 列表，包含可选选项：
  {
    "field_id": (字段的唯一 ID),
    "page": (页码，从 1 开始),
    "type": "choice",
    "choice_options": [
      {
        "value": (将字段设置为此值以选择此选项),
        "text": (选项的显示文本)
      },
      // 其他选项
    ],
  }
]
```
- 将 PDF 转换为 PNG 图片（每页一张图片），使用此脚本（从本文件所在目录运行）：
`python scripts/convert_pdf_to_images.py <file.pdf> <output_directory>`
然后分析图片以确定每个表单字段的用途（确保将边界框的 PDF 坐标转换为图片坐标）。
- 创建一个 `field_values.json` 文件，格式如下，包含每个字段要填入的值：
```
[
  {
    "field_id": "last_name", // 必须与 extract_form_field_info.py 中的 field_id 匹配
    "description": "用户的姓氏",
    "page": 1, // 必须与 field_info.json 中的 "page" 值匹配
    "value": "Simpson"
  },
  {
    "field_id": "Checkbox12",
    "description": "如果用户年满 18 岁则勾选的复选框",
    "page": 1,
    "value": "/On" // 如果是复选框，使用其 "checked_value" 值来勾选。如果是单选按钮组，使用 "radio_options" 中的某个 "value" 值。
  },
  // 更多字段
]
```
- 从本文件所在目录运行 `fill_fillable_fields.py` 脚本以创建填写完成的 PDF：
`python scripts/fill_fillable_fields.py <input pdf> <field_values.json> <output pdf>`
此脚本会验证你提供的字段 ID 和值是否有效；如果打印错误消息，请修正相应字段后重试。

## 不可填写字段

如果 PDF 没有可填写表单字段，你将添加文本注释。首先尝试从 PDF 结构中提取坐标（更精确），如果需要再回退到视觉估算。

### 步骤 1：先尝试结构提取

运行此脚本以提取文本标签、线条和复选框及其精确的 PDF 坐标：
`python scripts/extract_form_structure.py <input.pdf> form_structure.json`

这将创建一个 JSON 文件，包含：
- **labels**：每个文本元素及其精确坐标（PDF 点数中的 x0, top, x1, bottom）
- **lines**：定义行边界的水平线
- **checkboxes**：作为复选框的小矩形（含中心坐标）
- **row_boundaries**：从水平线计算的行顶部/底部位置

**检查结果**：如果 `form_structure.json` 中有有意义的标签（与表单字段对应的文本元素），使用**方法 A：基于结构的坐标**。如果 PDF 是扫描/图片形式且标签很少或没有，使用**方法 B：视觉估算**。

---

### 方法 A：基于结构的坐标（推荐）

当 `extract_form_structure.py` 在 PDF 中找到文本标签时使用此方法。

#### A.1：分析结构

读取 form_structure.json 并识别：

1. **标签组**：相邻的文本元素组成单个标签（例如 "Last" + "Name"）
2. **行结构**：具有相似 `top` 值的标签位于同一行
3. **字段列**：输入区域从标签结束处开始（x0 = label.x1 + 间隔）
4. **复选框**：直接使用结构中的复选框坐标

**坐标系**：PDF 坐标，y=0 在页面顶部，y 向下递增。

#### A.2：检查缺失元素

结构提取可能无法检测到所有表单元素。常见情况：
- **圆形复选框**：仅检测方形矩形作为复选框
- **复杂图形**：装饰元素或非标准表单控件
- **褪色或浅色元素**：可能无法提取

如果你在 PDF 图片中看到表单字段但不在 form_structure.json 中，需要对那些特定字段使用**视觉分析**（见下面的"混合方法"）。

#### A.3：使用 PDF 坐标创建 fields.json

对于每个字段，从提取的结构中计算输入坐标：

**文本字段：**
- entry x0 = label x1 + 5（标签后的小间隔）
- entry x1 = 下一个标签的 x0，或行边界
- entry top = 与 label top 相同
- entry bottom = 下方的行边界线，或 label bottom + 行高

**复选框：**
- 直接使用 form_structure.json 中的复选框矩形坐标
- entry_bounding_box = [checkbox.x0, checkbox.top, checkbox.x1, checkbox.bottom]

使用 `pdf_width` 和 `pdf_height` 创建 fields.json（表示 PDF 坐标）：
```json
{
  "pages": [
    {"page_number": 1, "pdf_width": 612, "pdf_height": 792}
  ],
  "form_fields": [
    {
      "page_number": 1,
      "description": "姓氏输入字段",
      "field_label": "Last Name",
      "label_bounding_box": [43, 63, 87, 73],
      "entry_bounding_box": [92, 63, 260, 79],
      "entry_text": {"text": "Smith", "font_size": 10}
    },
    {
      "page_number": 1,
      "description": "美国公民 Yes 复选框",
      "field_label": "Yes",
      "label_bounding_box": [260, 200, 280, 210],
      "entry_bounding_box": [285, 197, 292, 205],
      "entry_text": {"text": "X"}
    }
  ]
}
```

**重要**：使用 `pdf_width`/`pdf_height` 以及 form_structure.json 中的坐标。

#### A.4：验证边界框

填写前，检查边界框是否有错误：
`python scripts/check_bounding_boxes.py fields.json`

这会检查交叉的边界框和字体大小过小的输入框。在填写前修正所有报告的错误。

---

### 方法 B：视觉估算（回退方案）

当 PDF 是扫描/图片形式且结构提取未找到可用的文本标签时使用此方法（例如，所有文本显示为 "(cid:X)" 模式）。

#### B.1：将 PDF 转换为图片

`python scripts/convert_pdf_to_images.py <input.pdf> <images_dir/>`

#### B.2：初始字段识别

检查每页图片以识别表单区域并获取字段位置的**粗略估算**：
- 表单字段标签及其大致位置
- 输入区域（文本输入的线条、方框或空白区域）
- 复选框及其大致位置

对于每个字段，记录大致的像素坐标（暂时不需要精确）。

#### B.3：缩放精修（对精度至关重要）

对于每个字段，裁剪估算位置周围的区域以精确调整坐标。

**使用 ImageMagick 创建缩放裁剪：**
```bash
magick <page_image> -crop <width>x<height>+<x>+<y> +repage <crop_output.png>
```

其中：
- `<x>, <y>` = 裁剪区域的左上角（使用粗略估算值减去内边距）
- `<width>, <height>` = 裁剪区域的大小（字段区域加上每侧约 50px 内边距）

**示例：** 要精修估算在 (100, 150) 附近的"Name"字段：
```bash
magick images_dir/page_1.png -crop 300x80+50+120 +repage crops/name_field.png
```

（注意：如果 `magick` 命令不可用，尝试使用相同参数的 `convert`。）

**检查裁剪图片**以确定精确坐标：
1. 确定输入区域开始的精确像素位置（标签之后）
2. 确定输入区域结束的位置（下一个字段或边缘之前）
3. 确定输入行/方框的顶部和底部

**将裁剪坐标转换回完整图片坐标：**
- full_x = crop_x + crop_offset_x
- full_y = crop_y + crop_offset_y

示例：如果裁剪从 (50, 120) 开始，输入框在裁剪内从 (52, 18) 开始：
- entry_x0 = 52 + 50 = 102
- entry_top = 18 + 120 = 138

**对每个字段重复此操作**，尽可能将附近字段分组到单次裁剪中。

#### B.4：使用精修坐标创建 fields.json

使用 `image_width` 和 `image_height` 创建 fields.json（表示图片坐标）：
```json
{
  "pages": [
    {"page_number": 1, "image_width": 1700, "image_height": 2200}
  ],
  "form_fields": [
    {
      "page_number": 1,
      "description": "姓氏输入字段",
      "field_label": "Last Name",
      "label_bounding_box": [120, 175, 242, 198],
      "entry_bounding_box": [255, 175, 720, 218],
      "entry_text": {"text": "Smith", "font_size": 10}
    }
  ]
}
```

**重要**：使用 `image_width`/`image_height` 以及缩放分析中精修的像素坐标。

#### B.5：验证边界框

填写前，检查边界框是否有错误：
`python scripts/check_bounding_boxes.py fields.json`

这会检查交叉的边界框和字体大小过小的输入框。在填写前修正所有报告的错误。

---

### 混合方法：结构 + 视觉

当结构提取适用于大部分字段但遗漏了某些元素时使用此方法（例如，圆形复选框、非标准表单控件）。

1. 对 form_structure.json 中检测到的字段使用**方法 A**
2. 对缺失字段将 PDF 转换为图片进行视觉分析
3. 对缺失字段使用**缩放精修**（来自方法 B）
4. **合并坐标**：对于结构提取的字段，使用 `pdf_width`/`pdf_height`。对于视觉估算的字段，必须将图片坐标转换为 PDF 坐标：
   - pdf_x = image_x * (pdf_width / image_width)
   - pdf_y = image_y * (pdf_height / image_height)
5. 在 fields.json 中使用**单一坐标系** - 将所有坐标转换为 PDF 坐标并使用 `pdf_width`/`pdf_height`

---

### 步骤 2：填写前验证

**填写前始终验证边界框：**
`python scripts/check_bounding_boxes.py fields.json`

这会检查：
- 交叉的边界框（会导致文本重叠）
- 字体大小过小的输入框

在继续之前修正 fields.json 中所有报告的错误。

### 步骤 3：填写表单

填写脚本会自动检测坐标系统并处理转换：
`python scripts/fill_pdf_form_with_annotations.py <input.pdf> fields.json <output.pdf>`

### 步骤 4：验证输出

将填写完成的 PDF 转换为图片并验证文本位置：
`python scripts/convert_pdf_to_images.py <output.pdf> <verify_images/>`

如果文本位置不正确：
- **方法 A**：检查你使用的是 form_structure.json 中的 PDF 坐标，并配合 `pdf_width`/`pdf_height`
- **方法 B**：检查图片尺寸是否匹配，坐标是否为精确的像素值
- **混合方法**：确保视觉估算字段的坐标转换正确

---

---

# 附录 B：高级参考

本文档包含高级 PDF 处理功能、详细示例和主技能说明中未涵盖的附加库。

## pypdfium2 库（Apache/BSD 许可证）

### 概述
pypdfium2 是 PDFium（Chromium 的 PDF 库）的 Python 绑定。它非常适合快速 PDF 渲染、图片生成，可作为 PyMuPDF 的替代品。

### 渲染 PDF 为图片
```python
import pypdfium2 as pdfium
from PIL import Image

# 加载 PDF
pdf = pdfium.PdfDocument("document.pdf")

# 将页面渲染为图片
page = pdf[0]  # 第一页
bitmap = page.render(
    scale=2.0,  # 更高分辨率
    rotation=0  # 不旋转
)

# 转换为 PIL Image
img = bitmap.to_pil()
img.save("page_1.png", "PNG")

# 处理多页
for i, page in enumerate(pdf):
    bitmap = page.render(scale=1.5)
    img = bitmap.to_pil()
    img.save(f"page_{i+1}.jpg", "JPEG", quality=90)
```

### 使用 pypdfium2 提取文本
```python
import pypdfium2 as pdfium

pdf = pdfium.PdfDocument("document.pdf")
for i, page in enumerate(pdf):
    text = page.get_text()
    print(f"第 {i+1} 页文本长度: {len(text)} 字符")
```

## JavaScript 库

### pdf-lib（MIT 许可证）

pdf-lib 是一个强大的 JavaScript 库，用于在任何 JavaScript 环境中创建和修改 PDF 文档。

#### 加载和操作现有 PDF
```javascript
import { PDFDocument } from 'pdf-lib';
import fs from 'fs';

async function manipulatePDF() {
    // 加载现有 PDF
    const existingPdfBytes = fs.readFileSync('input.pdf');
    const pdfDoc = await PDFDocument.load(existingPdfBytes);

    // 获取页数
    const pageCount = pdfDoc.getPageCount();
    console.log(`文档共有 ${pageCount} 页`);

    // 添加新页面
    const newPage = pdfDoc.addPage([600, 400]);
    newPage.drawText('Added by pdf-lib', {
        x: 100,
        y: 300,
        size: 16
    });

    // 保存修改后的 PDF
    const pdfBytes = await pdfDoc.save();
    fs.writeFileSync('modified.pdf', pdfBytes);
}
```

#### 从零创建复杂 PDF
```javascript
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import fs from 'fs';

async function createPDF() {
    const pdfDoc = await PDFDocument.create();

    // 添加字体
    const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    // 添加页面
    const page = pdfDoc.addPage([595, 842]); // A4 尺寸
    const { width, height } = page.getSize();

    // 添加带样式的文本
    page.drawText('Invoice #12345', {
        x: 50,
        y: height - 50,
        size: 18,
        font: helveticaBold,
        color: rgb(0.2, 0.2, 0.8)
    });

    // 添加矩形（标题背景）
    page.drawRectangle({
        x: 40,
        y: height - 100,
        width: width - 80,
        height: 30,
        color: rgb(0.9, 0.9, 0.9)
    });

    // 添加类似表格的内容
    const items = [
        ['Item', 'Qty', 'Price', 'Total'],
        ['Widget', '2', '$50', '$100'],
        ['Gadget', '1', '$75', '$75']
    ];

    let yPos = height - 150;
    items.forEach(row => {
        let xPos = 50;
        row.forEach(cell => {
            page.drawText(cell, {
                x: xPos,
                y: yPos,
                size: 12,
                font: helveticaFont
            });
            xPos += 120;
        });
        yPos -= 25;
    });

    const pdfBytes = await pdfDoc.save();
    fs.writeFileSync('created.pdf', pdfBytes);
}
```

#### 高级合并和拆分操作
```javascript
import { PDFDocument } from 'pdf-lib';
import fs from 'fs';

async function mergePDFs() {
    // 创建新文档
    const mergedPdf = await PDFDocument.create();

    // 加载源 PDF
    const pdf1Bytes = fs.readFileSync('doc1.pdf');
    const pdf2Bytes = fs.readFileSync('doc2.pdf');

    const pdf1 = await PDFDocument.load(pdf1Bytes);
    const pdf2 = await PDFDocument.load(pdf2Bytes);

    // 从第一个 PDF 复制页面
    const pdf1Pages = await mergedPdf.copyPages(pdf1, pdf1.getPageIndices());
    pdf1Pages.forEach(page => mergedPdf.addPage(page));

    // 从第二个 PDF 复制特定页面（第 0、2、4 页）
    const pdf2Pages = await mergedPdf.copyPages(pdf2, [0, 2, 4]);
    pdf2Pages.forEach(page => mergedPdf.addPage(page));

    const mergedPdfBytes = await mergedPdf.save();
    fs.writeFileSync('merged.pdf', mergedPdfBytes);
}
```

### pdfjs-dist（Apache 许可证）

PDF.js 是 Mozilla 的 JavaScript 库，用于在浏览器中渲染 PDF。

#### 基本 PDF 加载和渲染
```javascript
import * as pdfjsLib from 'pdfjs-dist';

// 配置 worker（对性能很重要）
pdfjsLib.GlobalWorkerOptions.workerSrc = './pdf.worker.js';

async function renderPDF() {
    // 加载 PDF
    const loadingTask = pdfjsLib.getDocument('document.pdf');
    const pdf = await loadingTask.promise;

    console.log(`加载的 PDF 共有 ${pdf.numPages} 页`);

    // 获取第一页
    const page = await pdf.getPage(1);
    const viewport = page.getViewport({ scale: 1.5 });

    // 渲染到 canvas
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    const renderContext = {
        canvasContext: context,
        viewport: viewport
    };

    await page.render(renderContext).promise;
    document.body.appendChild(canvas);
}
```

#### 提取带坐标的文本
```javascript
import * as pdfjsLib from 'pdfjs-dist';

async function extractText() {
    const loadingTask = pdfjsLib.getDocument('document.pdf');
    const pdf = await loadingTask.promise;

    let fullText = '';

    // 从所有页面提取文本
    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();

        const pageText = textContent.items
            .map(item => item.str)
            .join(' ');

        fullText += `\n--- 第 ${i} 页 ---\n${pageText}`;

        // 获取带坐标的文本用于高级处理
        const textWithCoords = textContent.items.map(item => ({
            text: item.str,
            x: item.transform[4],
            y: item.transform[5],
            width: item.width,
            height: item.height
        }));
    }

    console.log(fullText);
    return fullText;
}
```

#### 提取注释和表单
```javascript
import * as pdfjsLib from 'pdfjs-dist';

async function extractAnnotations() {
    const loadingTask = pdfjsLib.getDocument('annotated.pdf');
    const pdf = await loadingTask.promise;

    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const annotations = await page.getAnnotations();

        annotations.forEach(annotation => {
            console.log(`注释类型: ${annotation.subtype}`);
            console.log(`内容: ${annotation.contents}`);
            console.log(`坐标: ${JSON.stringify(annotation.rect)}`);
        });
    }
}
```

## 高级命令行操作

### poppler-utils 高级功能

#### 提取带边界框坐标的文本
```bash
# 提取带边界框坐标的文本（对结构化数据至关重要）
pdftotext -bbox-layout document.pdf output.xml

# XML 输出包含每个文本元素的精确坐标
```

#### 高级图片转换
```bash
# 以特定分辨率转换为 PNG 图片
pdftoppm -png -r 300 document.pdf output_prefix

# 以高分辨率转换特定页面范围
pdftoppm -png -r 600 -f 1 -l 3 document.pdf high_res_pages

# 以指定质量转换为 JPEG
pdftoppm -jpeg -jpegopt quality=85 -r 200 document.pdf jpeg_output
```

#### 提取嵌入的图片
```bash
# 提取所有嵌入的图片及元数据
pdfimages -j -p document.pdf page_images

# 列出图片信息而不提取
pdfimages -list document.pdf

# 以原始格式提取图片
pdfimages -all document.pdf images/img
```

### qpdf 高级功能

#### 复杂页面操作
```bash
# 将 PDF 拆分为页面组
qpdf --split-pages=3 input.pdf output_group_%02d.pdf

# 使用复杂范围提取特定页面
qpdf input.pdf --pages input.pdf 1,3-5,8,10-end -- extracted.pdf

# 从多个 PDF 合并特定页面
qpdf --empty --pages doc1.pdf 1-3 doc2.pdf 5-7 doc3.pdf 2,4 -- combined.pdf
```

#### PDF 优化和修复
```bash
# 优化 PDF 用于网络（线性化以支持流式传输）
qpdf --linearize input.pdf optimized.pdf

# 移除未使用的对象并压缩
qpdf --optimize-level=all input.pdf compressed.pdf

# 尝试修复损坏的 PDF 结构
qpdf --check input.pdf
qpdf --fix-qdf damaged.pdf repaired.pdf

# 显示详细的 PDF 结构用于调试
qpdf --show-all-pages input.pdf > structure.txt
```

#### 高级加密
```bash
# 添加带特定权限的密码保护
qpdf --encrypt user_pass owner_pass 256 --print=none --modify=none -- input.pdf encrypted.pdf

# 检查加密状态
qpdf --show-encryption encrypted.pdf

# 移除密码保护（需要密码）
qpdf --password=secret123 --decrypt encrypted.pdf decrypted.pdf
```

## 高级 Python 技巧

### pdfplumber 高级功能

#### 提取带精确坐标的文本
```python
import pdfplumber

with pdfplumber.open("document.pdf") as pdf:
    page = pdf.pages[0]

    # 提取所有带坐标的文本
    chars = page.chars
    for char in chars[:10]:  # 前 10 个字符
        print(f"字符: '{char['text']}' 位于 x:{char['x0']:.1f} y:{char['y0']:.1f}")

    # 按边界框提取文本（左、上、右、下）
    bbox_text = page.within_bbox((100, 100, 400, 200)).extract_text()
```

#### 使用自定义设置的高级表格提取
```python
import pdfplumber
import pandas as pd

with pdfplumber.open("complex_table.pdf") as pdf:
    page = pdf.pages[0]

    # 使用自定义设置提取复杂布局的表格
    table_settings = {
        "vertical_strategy": "lines",
        "horizontal_strategy": "lines",
        "snap_tolerance": 3,
        "intersection_tolerance": 15
    }
    tables = page.extract_tables(table_settings)

    # 表格提取的可视化调试
    img = page.to_image(resolution=150)
    img.save("debug_layout.png")
```

### reportlab 高级功能

#### 高级分页控制

创建多页文档时，正确的分页可以防止过多的空白：

```python
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image,
    Table, LongTable, PageBreak, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

PAGE_WIDTH, PAGE_HEIGHT = letter
MARGIN = 0.75 * inch

doc = SimpleDocTemplate(
    "document.pdf",
    pagesize=letter,
    leftMargin=MARGIN,
    rightMargin=MARGIN,
    topMargin=MARGIN,
    bottomMargin=MARGIN
)

styles = getSampleStyleSheet()
story = []

# --- 封面页（独立） ---
cover_title_style = ParagraphStyle(
    'CoverTitle',
    parent=styles['Title'],
    fontSize=36,
    spaceAfter=30,
)
story.append(Spacer(1, 2 * inch))
story.append(Paragraph("Document Title", cover_title_style))
story.append(Paragraph("Subtitle or Author", styles['Normal']))
story.append(PageBreak())

# --- 正文内容（自然流动，可跨页分割） ---
heading_style = ParagraphStyle(
    'Heading',
    parent=styles['Heading1'],
    spaceBefore=12,
    spaceAfter=6,
)
body_style = ParagraphStyle(
    'Body',
    parent=styles['Normal'],
    fontSize=11,
    leading=14,
    spaceBefore=6,
    spaceAfter=6,
    wordWrap='CJK',
)

story.append(Paragraph("Chapter 1: Introduction", heading_style))
story.append(Paragraph("This is body text that can flow naturally across pages. "
                       "Long paragraphs will automatically split at page boundaries. "
                       "This maximizes page utilization and avoids blank space.", body_style))

# --- 图片与说明（保持在一起，不分割） ---
def add_figure(story, image_path, caption, width=4*inch):
    caption_style = ParagraphStyle('Caption', parent=styles['Normal'], fontSize=9, alignment=1)
    img = Image(image_path, width=width, height=width*0.75)
    story.append(KeepTogether([
        img,
        Spacer(1, 6),
        Paragraph(caption, caption_style)
    ]))

# add_figure(story, "chart.png", "Figure 1: Sales Chart")

# --- 小表格（保持在一起） ---
def add_small_table(story, data, col_widths):
    table = Table(data, colWidths=col_widths)
    table.setStyle([
        ('GRID', (0, 0), (-1, -1), 0.5, 'black'),
        ('BACKGROUND', (0, 0), (-1, 0), '#CCCCCC'),
    ])
    story.append(KeepTogether([table]))

# --- 大表格（按行分割，重复表头） ---
def add_large_table(story, data, col_widths):
    table = LongTable(data, colWidths=col_widths, repeatRows=1)
    table.splitByRow = True
    table.setStyle([
        ('GRID', (0, 0), (-1, -1), 0.5, 'black'),
        ('BACKGROUND', (0, 0), (-1, 0), '#CCCCCC'),
    ])
    story.append(table)

doc.build(story)
```

#### 创建带表格的专业报告（支持 CJK）
```python
import os
import platform
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# 注册 CJK 字体以支持非 ASCII 文本
def register_cjk_font():
    system = platform.system()
    if system == "Darwin":
        paths = ["/Library/Fonts/Arial Unicode.ttf", "/System/Library/Fonts/STHeiti Medium.ttc"]
    elif system == "Windows":
        paths = ["C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simsun.ttc"]
    else:
        paths = ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"]
    for p in paths:
        if os.path.exists(p):
            pdfmetrics.registerFont(TTFont("CJKFont", p, subfontIndex=0))
            return "CJKFont"
    return "Helvetica"

cjk_font = register_cjk_font()

# 包含中文的示例数据
data = [
    ['产品 Product', '第一季度 Q1', '第二季度 Q2', '第三季度 Q3', '第四季度 Q4'],
    ['部件 Widgets', '120', '135', '142', '158'],
    ['设备 Gadgets', '85', '92', '98', '105']
]

# 创建带表格的 PDF
doc = SimpleDocTemplate("report.pdf")
elements = []

# 添加支持 CJK 的标题
styles = getSampleStyleSheet()
cjk_title_style = ParagraphStyle('CJKTitle', parent=styles['Title'], fontName=cjk_font)
title = Paragraph("季度销售报告 Quarterly Sales Report", cjk_title_style)
elements.append(title)

# 添加带高级样式的表格（使用 CJK 字体）
table = Table(data)
table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
    ('FONTNAME', (0, 0), (-1, -1), cjk_font),  # 所有单元格使用 CJK 字体
    ('FONTSIZE', (0, 0), (-1, 0), 14),
    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
    ('GRID', (0, 0), (-1, -1), 1, colors.black)
]))
elements.append(table)

doc.build(elements)
```

#### matplotlib 图表支持 CJK

在为嵌入 PDF 创建 matplotlib 图表时：

```python
import os
import platform
import matplotlib.pyplot as plt
import matplotlib

def setup_matplotlib_cjk():
    """配置 matplotlib 以支持图表中的 CJK 字符"""
    system = platform.system()
    if system == "Darwin":
        font_names = ['Arial Unicode MS', 'PingFang SC', 'Heiti SC', 'STHeiti']
    elif system == "Windows":
        font_names = ['Microsoft YaHei', 'SimHei', 'SimSun']
    else:
        font_names = ['Noto Sans CJK SC', 'WenQuanYi Zen Hei', 'Droid Sans Fallback']

    available_fonts = [f.name for f in matplotlib.font_manager.fontManager.ttflist]
    for font_name in font_names:
        if font_name in available_fonts:
            plt.rcParams['font.sans-serif'] = [font_name] + plt.rcParams['font.sans-serif']
            plt.rcParams['axes.unicode_minus'] = False
            return font_name
    return None

# 创建任何图表之前先设置
cjk_font = setup_matplotlib_cjk()

# 创建带中文标签的饼图
labels = ['研发 R&D', '市场 Marketing', '运营 Operations', '销售 Sales']
sizes = [30, 25, 20, 25]
colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99']

plt.figure(figsize=(8, 8))
plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
plt.title('部门预算分配 Budget Allocation', fontsize=16)
plt.axis('equal')
plt.tight_layout()
plt.savefig('pie_chart.png', dpi=150, bbox_inches='tight')
plt.close()
```

#### CJK 长文本自动换行

对于需要正确换行的长中文文本：

```python
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import ParagraphStyle

# 重要：设置 wordWrap='CJK' 以实现正确的中文换行
cjk_paragraph_style = ParagraphStyle(
    'CJKParagraph',
    fontName='CJKFont',
    fontSize=12,
    leading=18,
    wordWrap='CJK',  # 对中文换行至关重要
)

doc = SimpleDocTemplate("long_text.pdf")
story = []

long_chinese_text = """
这是一段很长的中文文本，用于演示中文换行功能。在没有设置 wordWrap='CJK' 的情况下，
reportlab 默认使用英文换行规则，只在空格处换行。但中文句子通常没有空格，
因此需要特别设置 CJK 换行模式，才能让文本在适当的位置自动换行。
"""
story.append(Paragraph(long_chinese_text, cjk_paragraph_style))

doc.build(story)
```

## 复杂工作流

### 从 PDF 中提取图片/图形

#### 方法 1：使用 pdfimages（最快）
```bash
# 以原始质量提取所有图片
pdfimages -all document.pdf images/img
```

#### 方法 2：使用 pypdfium2 + 图片处理
```python
import pypdfium2 as pdfium
from PIL import Image
import numpy as np

def extract_figures(pdf_path, output_dir):
    pdf = pdfium.PdfDocument(pdf_path)

    for page_num, page in enumerate(pdf):
        # 渲染高分辨率页面
        bitmap = page.render(scale=3.0)
        img = bitmap.to_pil()

        # 转换为 numpy 进行处理
        img_array = np.array(img)

        # 简单的图形检测（非白色区域）
        mask = np.any(img_array != [255, 255, 255], axis=2)

        # 查找轮廓并提取边界框
        # （这是简化版本 - 实际实现需要更复杂的检测）

        # 保存检测到的图形
        # ... 实现取决于具体需求
```

### 带错误处理的批量 PDF 处理
```python
import os
import glob
from pypdf import PdfReader, PdfWriter
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def batch_process_pdfs(input_dir, operation='merge'):
    pdf_files = glob.glob(os.path.join(input_dir, "*.pdf"))

    if operation == 'merge':
        writer = PdfWriter()
        for pdf_file in pdf_files:
            try:
                reader = PdfReader(pdf_file)
                for page in reader.pages:
                    writer.add_page(page)
                logger.info(f"已处理: {pdf_file}")
            except Exception as e:
                logger.error(f"处理失败 {pdf_file}: {e}")
                continue

        with open("batch_merged.pdf", "wb") as output:
            writer.write(output)

    elif operation == 'extract_text':
        for pdf_file in pdf_files:
            try:
                reader = PdfReader(pdf_file)
                text = ""
                for page in reader.pages:
                    text += page.extract_text()

                output_file = pdf_file.replace('.pdf', '.txt')
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(text)
                logger.info(f"已从以下文件提取文本: {pdf_file}")

            except Exception as e:
                logger.error(f"提取文本失败 {pdf_file}: {e}")
                continue
```

### 高级 PDF 裁剪
```python
from pypdf import PdfWriter, PdfReader

reader = PdfReader("input.pdf")
writer = PdfWriter()

# 裁剪页面（左、下、右、上，单位为点）
page = reader.pages[0]
page.mediabox.left = 50
page.mediabox.bottom = 50
page.mediabox.right = 550
page.mediabox.top = 750

writer.add_page(page)
with open("cropped.pdf", "wb") as output:
    writer.write(output)
```

## 性能优化技巧

### 1. 对于大型 PDF
- 使用流式方法而非将整个 PDF 加载到内存
- 使用 `qpdf --split-pages` 拆分大文件
- 使用 pypdfium2 逐页处理

### 2. 对于文本提取
- `pdftotext -bbox-layout` 是纯文本提取最快的方式
- 使用 pdfplumber 处理结构化数据和表格
- 避免对非常大的文档使用 `pypdf.extract_text()`

### 3. 对于图片提取
- `pdfimages` 比渲染页面快得多
- 预览使用低分辨率，最终输出使用高分辨率

### 4. 对于表单填写
- pdf-lib 比大多数替代方案更好地维护表单结构
- 处理前先预验证表单字段

### 5. 内存管理
```python
# 分块处理 PDF
def process_large_pdf(pdf_path, chunk_size=10):
    reader = PdfReader(pdf_path)
    total_pages = len(reader.pages)

    for start_idx in range(0, total_pages, chunk_size):
        end_idx = min(start_idx + chunk_size, total_pages)
        writer = PdfWriter()

        for i in range(start_idx, end_idx):
            writer.add_page(reader.pages[i])

        # 处理分块
        with open(f"chunk_{start_idx//chunk_size}.pdf", "wb") as output:
            writer.write(output)
```

## 常见问题排查

### 加密 PDF
```python
# 处理密码保护的 PDF
from pypdf import PdfReader

try:
    reader = PdfReader("encrypted.pdf")
    if reader.is_encrypted:
        reader.decrypt("password")
except Exception as e:
    print(f"解密失败: {e}")
```

### 损坏的 PDF
```bash
# 使用 qpdf 修复
qpdf --check corrupted.pdf
qpdf --replace-input corrupted.pdf
```

### 文本提取问题
```python
# 对扫描版 PDF 回退到 OCR
import pytesseract
from pdf2image import convert_from_path

def extract_text_with_ocr(pdf_path):
    images = convert_from_path(pdf_path)
    text = ""
    for i, image in enumerate(images):
        text += pytesseract.image_to_string(image)
    return text
```

## 许可证信息

- **pypdf**: BSD 许可证
- **pdfplumber**: MIT 许可证
- **pypdfium2**: Apache/BSD 许可证
- **reportlab**: BSD 许可证
- **poppler-utils**: GPL-2 许可证
- **qpdf**: Apache 许可证
- **pdf-lib**: MIT 许可证
- **pdfjs-dist**: Apache 许可证
