---
name: docx
description: "Comprehensive document creation, editing, and analysis with support for tracked changes, comments, formatting preservation, and text extraction. When you need to work with professional documents (.docx files) for: (1) Creating new documents, (2) Modifying or editing content, (3) Working with tracked changes, (4) Adding comments, or any other document tasks"
metadata:
  author: trae-skill
  version: "1.0.0"
  category: office-automation
  tags: [word, docx, document, editing, tracked-changes, comments]
---

# DOCX Skill — Word 文档处理专家

## 概述

本技能提供全面的 Word (.docx) 文档处理能力，包括创建新文档、编辑现有文档、修订追踪、批注管理和格式保留。.docx 文件本质上是包含 XML 文件的 ZIP 压缩包。

## 触发条件

当用户请求涉及以下内容时自动触发：
- 创建新的 Word 文档
- 修改或编辑现有文档内容
- 处理修订追踪（tracked changes）
- 添加或管理批注
- 提取文档文本内容
- 转换文档格式

---

# 快速参考

| 任务 | 方法 |
|------|------|
| 读取/分析内容 | `pandoc` 或解压查看原始 XML |
| 创建新文档 | 使用 `docx-js` - 见下方"创建新文档" |
| 编辑现有文档 | 解压 → 编辑 XML → 重新打包 - 见下方"编辑现有文档" |

### 转换 .doc 为 .docx

旧版 `.doc` 文件必须先转换才能编辑：

```bash
soffice --headless --convert-to docx document.doc
```

### 读取内容

```bash
# 带修订追踪的文本提取
pandoc --track-changes=all document.docx -o output.md

# 原始 XML 访问
python scripts/unpack.py document.docx unpacked/
```

### 转换为图片

```bash
soffice --headless --convert-to pdf document.docx
pdftoppm -jpeg -r 150 document.pdf page
```

### 接受所有修订

生成接受所有跟踪更改的干净文档（需要 LibreOffice）：

```bash
python scripts/accept_changes.py input.docx output.docx
```

---

# 创建新文档

使用 JavaScript 生成 .docx 文件。安装：`npm install -g docx`

**⚠️ 关键：在 docx-js 中使用 JavaScript 转义符 (`"`)，绝不要使用 XML 实体 (`&#x201C;`) - 它们会显示为乱码。**

生成新 docx 后，务必运行：

```bash
python scripts/sanitize.py input.docx
```

## 基础设置

```javascript
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun,
        Header, Footer, AlignmentType, PageOrientation, LevelFormat, ExternalHyperlink,
        HeadingLevel, BorderStyle, WidthType, ShadingType,
        VerticalAlign, PageNumber, PageBreak } = require('docx');

// 关键：只使用一个 section - 多个 section 会产生空白页
const doc = new Document({ sections: [{ children: [/* 所有内容放这里 */] }] });
Packer.toBuffer(doc).then(buffer => fs.writeFileSync("doc.docx", buffer));
```

## 页面尺寸

```javascript
// 关键：docx-js 默认使用 A4，不是 US Letter
// 始终显式设置页面尺寸以获得一致结果
sections: [{
  properties: {
    page: {
      size: {
        width: 12240,   // 8.5 英寸，单位为 DXA
        height: 15840   // 11 英寸，单位为 DXA
      },
      margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } // 1 英寸边距
    }
  },
  children: [/* 所有内容放在这个单一 section 中 */]
}]
```

**常用页面尺寸（DXA 单位，1440 DXA = 1 英寸）：**

| 纸张 | 宽度 | 高度 | 内容宽度（1英寸边距） |
|------|------|------|---------------------|
| US Letter | 12,240 | 15,840 | 9,360 |
| A4（默认） | 11,906 | 16,838 | 9,026 |

## 字体和 CJK 支持

**关键：对于包含中文/日文/韩文的文档，必须为 ASCII 和东亚字符配置字体。** 仅使用 ASCII 字体（如 Arial）会导致 CJK 字符显示不正确或显示为方框。

### 按字符类型配置字体

Word 文档对不同字符类型使用不同的字体槽位：
- `ascii` / `hAnsi`: 拉丁字符（A-Z, a-z, 数字）
- `eastAsia`: CJK 字符（中文、日文、韩文）
- `cs`: 复杂脚本（阿拉伯语、希伯来语等）

### 推荐字体组合

| 平台 | ASCII/Latin | 东亚（CJK） |
|------|-------------|------------|
| 跨平台 | Arial | Microsoft YaHei |
| macOS | Arial | PingFang SC |
| Windows | Arial | SimSun 或 SimHei |
| Linux | DejaVu Sans | Noto Sans CJK SC |

**最佳实践**：对 CJK 使用 `Microsoft YaHei`，因为它在大多数平台都可用且渲染效果好。

### 基础字体设置（仅 ASCII - 英文文档）

```javascript
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 24 } } }
  }
});
```

### CJK 字体设置（中文/日文/韩文文档）

```javascript
const doc = new Document({
  styles: {
    default: {
      document: {
        run: {
          font: {
            ascii: "Arial",
            hAnsi: "Arial",
            eastAsia: "Microsoft YaHei"
          },
          size: 24
        }
      }
    },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: {
          size: 32, bold: true,
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" }
        },
        paragraph: { spacing: { before: 240, after: 240 }, outlineLevel: 0, keepNext: false, keepLines: false } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: {
          size: 28, bold: true,
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" }
        },
        paragraph: { spacing: { before: 180, after: 180 }, outlineLevel: 1, keepNext: false, keepLines: false } },
    ]
  },
  sections: [{
    children: [
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("标题 Title")] }),
    ]
  }]
});
```

### 平台自适应字体选择

为获得跨操作系统的最大兼容性：

```javascript
const os = require('os');

function getCJKFont() {
  const platform = os.platform();
  if (platform === 'darwin') {
    return 'PingFang SC';  // macOS
  } else if (platform === 'win32') {
    return 'Microsoft YaHei';  // Windows
  } else {
    return 'Noto Sans CJK SC';  // Linux
  }
}

const cjkFont = getCJKFont();
const doc = new Document({
  styles: {
    default: {
      document: {
        run: {
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: cjkFont },
          size: 24
        }
      }
    }
  }
});
```

## 样式（覆盖内置标题）

保持标题为黑色以提高可读性。设置 `keepNext: false` 和 `keepLines: false` 以允许自然页面流。

```javascript
const doc = new Document({
  styles: {
    default: {
      document: {
        run: {
          font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" },
          size: 24
        }
      }
    },
    paragraphStyles: [
      // 重要：使用精确 ID 覆盖内置样式
      // 重要：设置 keepNext/keepLines 为 false 以允许自然页面流
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" } },
        paragraph: { spacing: { before: 240, after: 240 }, outlineLevel: 0, keepNext: false, keepLines: false } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" } },
        paragraph: { spacing: { before: 180, after: 180 }, outlineLevel: 1, keepNext: false, keepLines: false } },
    ]
  },
  sections: [{
    children: [
      new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("标题 Title")] }),
    ]
  }]
});
```

## docx-js 中的特殊字符

**⚠️ 关键：使用 JavaScript 转义符，不要使用 XML 实体。**

| 需要写入 | ✅ 正确（JavaScript） | ❌ 错误（XML 实体） |
|----------|----------------------|-------------------|
| 双引号 `"` | `"` | `&#x201C;` `&#x201D;` `&#34;` |
| 单引号 `'` | `` | `&#x2018;` `&#x2019;` `&#39;` |
| 与号 `&` | `&`（无需转义） | `&amp;` |
| 小于号 `<` | `<`（无需转义） | `&lt;` |

```javascript
// ✅ 正确 - 使用 JavaScript 反斜杠转义
new TextRun("这是中文内容")
new TextRun("He said \"Hello\" and replied \"你好\"")
new TextRun("包含\"双引号\"的内容")

// ❌ 错误 - XML 实体会在文档中显示为乱码
new TextRun("&#x201C;Hello&#x201D;")  // 显示为: &#x201C;Hello&#x201D;
new TextRun("Tom&#x2019;s book")  // 显示为: Tom&#x2019;s book

// ❌ 错误 - 不要将字符转换为 \uXXXX 转义
new TextRun("\u8fd9\u662f\u4e2d\u6587")  // 使代码不可读
```

**记住：**
- docx-js 在内部处理 XML - 你编写的是 JavaScript 字符串，不是 XML
- XML 实体仅在"编辑现有文档"工作流（原始 XML 编辑）中使用
- 不确定时，对引号使用 `\"`

## 列表（不要使用 unicode 项目符号）

```javascript
// ❌ 错误 - 不要手动插入项目符号字符
new Paragraph({ children: [new TextRun("• Item")] })  // 错误
new Paragraph({ children: [new TextRun("\u2022 Item")] })  // 错误

// ✅ 正确 - 使用 numbering config 配合 LevelFormat.BULLET
const doc = new Document({
  numbering: {
    config: [
      { reference: "bullets",
        levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "numbers",
        levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ]
  },
  sections: [{
    children: [
      new Paragraph({ numbering: { reference: "bullets", level: 0 },
        children: [new TextRun("Bullet item")] }),
      new Paragraph({ numbering: { reference: "numbers", level: 0 },
        children: [new TextRun("Numbered item")] }),
    ]
  }]
});

// ⚠️ 每个 reference 创建独立的编号
// 相同 reference = 继续 (1,2,3 然后 4,5,6)
// 不同 reference = 重新开始 (1,2,3 然后 1,2,3)
```

## 表格

**关键：表格需要双重宽度** - 在表格上设置 `columnWidths`，在每个单元格上设置 `width`。缺少任一都会导致在某些平台上渲染不正确。

**关键：表格不应跨页分割** - 在 TableRow 上使用 `cantSplit: true` 保持每行完整。

```javascript
// 关键：始终设置表格宽度以获得一致渲染
// 关键：使用 ShadingType.CLEAR（不是 SOLID）以防止黑色背景
// 关键：使用 cantSplit: true 防止行跨页分割
const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };

new Table({
  width: { size: 100, type: WidthType.PERCENTAGE }, // 始终设置表格宽度
  columnWidths: [4680, 4680], // 在表格级别设置（DXA: 1440 = 1 英寸）
  rows: [
    new TableRow({
      cantSplit: true, // 防止行跨页分割
      children: [
        new TableCell({
          borders,
          width: { size: 4680, type: WidthType.DXA }, // 也在每个单元格上设置
          shading: { fill: "D5E8F0", type: ShadingType.CLEAR }, // CLEAR 不是 SOLID
          margins: { top: 80, bottom: 80, left: 120, right: 120 }, // 单元格内边距（内部，不添加到宽度）
          children: [new Paragraph({ children: [new TextRun("Cell")] })]
        })
      ]
    })
  ]
})
```

**表格宽度计算：**

为简便使用 `WidthType.PERCENTAGE`，或使用 `WidthType.DXA` 进行精确控制：

```javascript
// 选项 1: 百分比（推荐 - 自动适应内容区域）
width: { size: 100, type: WidthType.PERCENTAGE }

// 选项 2: DXA（精确控制）
// 表格宽度 = columnWidths 之和 = 内容宽度
// US Letter 带 1" 边距: 12240 - 2880 = 9360 DXA
width: { size: 9360, type: WidthType.DXA },
columnWidths: [7000, 2360]  // 必须等于表格宽度
```

**宽度规则：**
- 表格宽度必须等于 `columnWidths` 之和
- 单元格 `width` 必须匹配对应的 `columnWidth`
- 单元格 `margins` 是内部内边距 - 它们减少内容区域，不添加到单元格宽度
- 对于全宽表格：使用内容宽度（页面宽度减去左右边距）

## 图片

```javascript
// 关键：type 参数是必需的
new Paragraph({
  children: [new ImageRun({
    type: "png", // 必需: png, jpg, jpeg, gif, bmp, svg
    data: fs.readFileSync("image.png"),
    transformation: { width: 200, height: 150 },
    altText: { title: "Title", description: "Desc", name: "Name" } // 三个都是必需的
  })]
})
```

## 分页符和分页

**分页策略：**
- **封面页**：封面内容后使用显式 PageBreak
- **图片/表格**：保持完整，不要跨页分割
- **标题/段落**：允许自然流，不要强制分页

```javascript
// 关键：PageBreak 必须在 Paragraph 内部
new Paragraph({ children: [new PageBreak()] })

// 或使用 pageBreakBefore（谨慎使用 - 仅用于封面页或主要章节）
new Paragraph({ pageBreakBefore: true, children: [new TextRun("New page")] })
```

**重要：避免过多空白** - Word 的默认标题样式设置 `keepNext: true` 强制标题与后续段落保持在一起。这会导致页面底部只有标题和大片空白区域。始终在标题样式上设置 `keepNext: false` 和 `keepLines: false`（见上方样式部分）。

**⚠️ 关键：每个 section 至少生成一页。如果你创建一个空 section（例如只有页面属性和 `children: []`）后跟一个内容 section，空 section 将渲染为空白首页。改为在单个 section 内使用 `PageBreak`。**

## 页眉/页脚

```javascript
sections: [{
  properties: {
    page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } // 1440 = 1 英寸
  },
  headers: {
    default: new Header({ children: [new Paragraph({ children: [new TextRun("Header")] })] })
  },
  footers: {
    default: new Footer({ children: [new Paragraph({
      children: [new TextRun("Page "), new TextRun({ children: [PageNumber.CURRENT] })]
    })] })
  },
  children: [/* content */]
}]
```

## docx-js 关键规则

- **只使用一个 section** - 将所有内容放在单个 section 的 `children` 数组中。多个 section 会导致空白页（每个空 section 渲染为空白页）。永远不要创建空 section 后跟内容 section
- **显式设置页面尺寸** - docx-js 默认为 A4；对 US 文档使用 US Letter (12240 x 15840 DXA)
- **为中文/日文/韩文配置 CJK 字体** - 使用 `font: { ascii: "Arial", hAnsi: "Arial", eastAsia: "Microsoft YaHei" }` 防止乱码
- **对引号使用 JavaScript 转义** - 使用 `"` 而不是 XML 实体；`&#x201C;` 会显示为乱码
- **不要使用 `\n`** - 使用单独的 Paragraph 元素
- **不要使用 unicode 项目符号** - 使用 `LevelFormat.BULLET` 配合 numbering config
- **PageBreak 必须在 Paragraph 中** - 单独创建会产生无效 XML
- **ImageRun 需要 `type`** - 始终指定 png/jpg 等
- **始终设置表格 `width`** - 使用 `{ size: 100, type: WidthType.PERCENTAGE }` 获得全宽
- **表格需要双重宽度** - `columnWidths` 数组和单元格 `width`，两者必须匹配
- **表格宽度 = columnWidths 之和** - 对于 DXA，确保它们精确相加
- **始终添加单元格边距** - 使用 `margins: { top: 80, bottom: 80, left: 120, right: 120 }` 获得可读内边距
- **使用 `ShadingType.CLEAR`** - 永远不要对表格底纹使用 SOLID
- **覆盖内置样式** - 使用精确 ID: "Heading1", "Heading2" 等
- **包含 `outlineLevel`** - 标题样式中必需（H1 为 0，H2 为 1 等）
- **在标题上设置 `keepNext: false`** - 防止标题被推到下一页导致的过多空白
- **在表格行上设置 `cantSplit: true`** - 保持表格在页面边界完整
- **不要目录页** - 不要生成任何 TOC 或目录页；直接从文档内容开始
- **创建后始终运行 sanitize.py** - 它会检查并移除纯文本 TOC 块和多余的空白页

---

# 编辑现有文档

**⚠️ 本节用于编辑原始 XML 文件（解压/打包工作流）。XML 实体 (`&#x201C;`) 仅在此处有效，在上方的 docx-js 代码中无效。**

**按顺序执行所有 3 个步骤。**

## 步骤 1: 解压

```bash
python scripts/unpack.py document.docx unpacked/
```

提取 XML，美化打印，合并相邻 runs，并将智能引号转换为 XML 实体（`&#x201C;` 等）以便编辑时保留。使用 `--merge-runs false` 跳过 run 合并。

## 步骤 2: 编辑 XML

编辑 `unpacked/word/` 中的文件。XML 参考见下方。

**修订追踪和批注使用 "AI Assistant" 作为作者**，除非用户明确要求使用其他名称。

**直接使用 Edit 工具进行字符串替换。不要编写 Python 脚本。** 脚本引入不必要的复杂性。Edit 工具准确显示正在替换的内容。

**关键：新内容使用智能引号。** 添加带撇号或引号的文本时，使用 XML 实体生成智能引号：

```xml
<!-- 使用这些实体获得专业排版 -->
<w:t>Here&#x2019;s a quote: &#x201C;Hello&#x201D;</w:t>
```

| 实体 | 字符 |
|------|------|
| `&#x2018;` | '（左单引号） |
| `&#x2019;` | '（右单引号 / 撇号） |
| `&#x201C;` | "（左双引号） |
| `&#x201D;` | "（右双引号） |

**添加批注：** 使用 `comment.py` 处理跨多个 XML 文件的样板代码（文本必须是预转义的 XML）：

```bash
python scripts/comment.py unpacked/ 0 "Comment text with &amp; and &#x2019;"
python scripts/comment.py unpacked/ 1 "Reply text" --parent 0  # 回复批注 0
python scripts/comment.py unpacked/ 0 "Text" --author "Custom Author"  # 自定义作者名
```

然后在 document.xml 中添加标记（见 XML 参考中的批注部分）。

## 步骤 3: 打包

```bash
python scripts/pack.py unpacked/ output.docx --original document.docx
```

使用自动修复验证，压缩 XML，创建 DOCX。使用 `--validate false` 跳过验证。

**自动修复会修复：**
- `durableId` >= 0x7FFFFFFF（重新生成有效 ID）
- `<w:t>` 上缺少 `xml:space="preserve"` 的空白字符

**自动修复不会修复：**
- 格式错误的 XML、无效的元素嵌套、缺失的关系、schema 违规

## 常见陷阱

- **替换整个 `<w:r>` 元素**：添加跟踪更改时，将整个 `<w:r>...</w:r>` 块替换为 `<w:del>...<w:ins>...` 作为同级元素。不要在 run 内部注入跟踪更改标签。
- **保留 `<w:rPr>` 格式**：将原始 run 的 `<w:rPr>` 块复制到你的跟踪更改 runs 中以保持粗体、字体大小等。

---

# XML 参考

## Schema 合规性

- **`<w:pPr>` 中的元素顺序**：`<w:pStyle>`、`<w:numPr>`、`<w:spacing>`、`<w:ind>`、`<w:jc>`、`<w:rPr>` 最后
- **空白字符**：对带有前导/尾随空格的 `<w:t>` 添加 `xml:space="preserve"`
- **RSIDs**：必须是 8 位十六进制（例如 `00AB1234`）

## 修订追踪

**插入：**

```xml
<w:ins w:id="1" w:author="AI Assistant" w:date="2025-01-01T00:00:00Z">
  <w:r><w:t>inserted text</w:t></w:r>
</w:ins>
```

**删除：**

```xml
<w:del w:id="2" w:author="AI Assistant" w:date="2025-01-01T00:00:00Z">
  <w:r><w:delText>deleted text</w:delText></w:r>
</w:del>
```

**在 `<w:del>` 内部**：使用 `<w:delText>` 代替 `<w:t>`，使用 `<w:delInstrText>` 代替 `<w:instrText>`。

**最小化编辑** - 只标记变化的内容：

```xml
<!-- 将 "30 days" 改为 "60 days" -->
<w:r><w:t>The term is </w:t></w:r>
<w:del w:id="1" w:author="AI Assistant" w:date="...">
  <w:r><w:delText>30</w:delText></w:r>
</w:del>
<w:ins w:id="2" w:author="AI Assistant" w:date="...">
  <w:r><w:t>60</w:t></w:r>
</w:ins>
<w:r><w:t> days.</w:t></w:r>
```

**删除整个段落/列表项** - 当从段落中移除所有内容时，也将段落标记标记为删除以便与下一个段落合并。在 `<w:pPr><w:rPr>` 中添加 `<w:del/>`：

```xml
<w:p>
  <w:pPr>
    <w:numPr>...</w:numPr>  <!-- 列表编号（如果存在） -->
    <w:rPr>
      <w:del w:id="1" w:author="AI Assistant" w:date="2025-01-01T00:00:00Z"/>
    </w:rPr>
  </w:pPr>
  <w:del w:id="2" w:author="AI Assistant" w:date="2025-01-01T00:00:00Z">
    <w:r><w:delText>Entire paragraph content being deleted...</w:delText></w:r>
  </w:del>
</w:p>
```

没有在 `<w:pPr><w:rPr>` 中的 `<w:del/>`，接受更改后会留下空段落/列表项。

**拒绝另一位作者的插入** - 将删除嵌套在他们的插入中：

```xml
<w:ins w:author="Jane" w:id="5">
  <w:del w:author="AI Assistant" w:id="10">
    <w:r><w:delText>their inserted text</w:delText></w:r>
  </w:del>
</w:ins>
```

**恢复另一位作者的删除** - 在其后添加插入（不要修改他们的删除）：

```xml
<w:del w:author="Jane" w:id="5">
  <w:r><w:delText>deleted text</w:delText></w:r>
</w:del>
<w:ins w:author="AI Assistant" w:id="10">
  <w:r><w:t>deleted text</w:t></w:r>
</w:ins>
```

## 批注

运行 `comment.py` 后（见步骤 2），在 document.xml 中添加标记。对于回复，使用 `--parent` 标志并在父批注内部嵌套标记。

**关键：`<w:commentRangeStart>` 和 `<w:commentRangeEnd>` 是 `<w:r>` 的同级元素，绝不在 `<w:r>` 内部。**

```xml
<!-- 批注标记是 w:p 的直接子元素，绝不在 w:r 内部 -->
<w:commentRangeStart w:id="0"/>
<w:del w:id="1" w:author="AI Assistant" w:date="2025-01-01T00:00:00Z">
  <w:r><w:delText>deleted</w:delText></w:r>
</w:del>
<w:r><w:t> more text</w:t></w:r>
<w:commentRangeEnd w:id="0"/>
<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="0"/></w:r>

<!-- 批注 0 与回复 1 嵌套在内部 -->
<w:commentRangeStart w:id="0"/>
  <w:commentRangeStart w:id="1"/>
  <w:r><w:t>text</w:t></w:r>
  <w:commentRangeEnd w:id="1"/>
<w:commentRangeEnd w:id="0"/>
<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="0"/></w:r>
<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="1"/></w:r>
```

## 图片

1. 将图片文件添加到 `word/media/`
2. 添加关系到 `word/_rels/document.xml.rels`：

```xml
<Relationship Id="rId5" Type=".../image" Target="media/image1.png"/>
```

3. 添加内容类型到 `[Content_Types].xml`：

```xml
<Default Extension="png" ContentType="image/png"/>
```

4. 在 document.xml 中引用：

```xml
<w:drawing>
  <wp:inline>
    <wp:extent cx="914400" cy="914400"/>  <!-- EMUs: 914400 = 1 英寸 -->
    <a:graphic>
      <a:graphicData uri=".../picture">
        <pic:pic>
          <pic:blipFill><a:blip r:embed="rId5"/></pic:blipFill>
        </pic:pic>
      </a:graphicData>
    </a:graphic>
  </wp:inline>
</w:drawing>
```

---

# 依赖项

- **pandoc**: 文本提取
- **docx**: `npm install -g docx`（新文档）
- **LibreOffice**: PDF 转换
- **Poppler**: `pdftoppm` 用于图片

---

# 脚本工具说明

本技能附带以下脚本工具，位于 `scripts/` 目录下：

| 脚本 | 用途 |
|------|------|
| `unpack.py` | 解压 DOCX 为可编辑的 XML 文件 |
| `pack.py` | 将 XML 文件重新打包为 DOCX |
| `accept_changes.py` | 使用 LibreOffice 接受所有修订 |
| `comment.py` | 向文档添加批注 |
| `sanitize.py` | 清理文档输出（移除 TOC、多余分页符） |
| `helpers/merge_runs.py` | 合并相邻的文本 runs |
| `helpers/simplify_redlines.py` | 简化修订标记 |
| `ooxml/scripts/` | OOXML 通用工具（pack/unpack/validate） |
| `ooxml/validation/` | 文档验证器（docx/pptx/redlining） |
| `ooxml/schemas/` | ISO/IEC 29500 XML Schema 定义文件 |
| `templates/` | XML 模板文件（comments.xml 等） |
